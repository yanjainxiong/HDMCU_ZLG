/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file uart_common.c
 **
 ** This source code supports the operation of uart to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "uart_comm.h"
#include "uart.h"
#include "gpio.h"

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/
stcUartRxBuf_t stcUartRxBuf;

/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/
uint32_t MyStrlen(uint8_t *pAddr)
{
    uint32_t length = 0;
    while (1)
    {
        if ( '\0' == *pAddr++)
        {
            return length;
        }
        length++;
    }
}  

/**
 ******************************************************************************
 ** \brief Uart send a char
 **
 ** \param The sent data
 **
 ** \return 
 **
 ******************************************************************************/
void UartSendByte(uint8_t dat)
{   
    while(TRUE != Uart_GetStatus(UART_COMM_CHANNLE, UartTxIdle));
    while (TRUE != Uart_GetStatus(UART_COMM_CHANNLE, UartTxEmpty)); /* wait until TX buffer empty */
    Uart_SendData(UART_COMM_CHANNLE, dat);
    return;
}


/**
 ******************************************************************************
 ** \brief Uart send a string 
 **
 ** \param pAddr Pointer about a string
 **
 ** \return 
 **
 ******************************************************************************/

void UartWriteString(uint8_t *pAddr)
{
    uint32_t length; 
    if ( NULL == pAddr )
    {
        return;
    }    
    length = MyStrlen(pAddr);
    for (; length>0; length--)
    {
        UartSendByte(*pAddr);
        pAddr++;
    }

    return;
}


/**
 ******************************************************************************
 ** \brief  uart interrupt ISR
 **
 ** \return 
 ******************************************************************************/
void Uart_RX_IRQHandler()
{
    uint8_t dat;
      
    dat = Uart_ReceiveData(UART_COMM_CHANNLE);
      
    if ( TRUE == stcUartRxBuf.RxFlg)
    {
        return;
    }
      
    if (( 0xD == dat) || (0xA == dat)) // if received "Enter Key", return
    {
        if(0xD == dat)  //add
        {
            stcUartRxBuf.RxFlg = TRUE;
            UartWriteString("\r\n");
        }
        return;
    }
    
    if ( stcUartRxBuf.RxCnt >= (UARTMAXBUFFRTSIZE-1))
    {
        return;
    }

    UartSendByte(dat);
    stcUartRxBuf.UartRx[stcUartRxBuf.RxCnt] = dat;
    stcUartRxBuf.RxCnt++;

    return;
}

/**
 ******************************************************************************
 ** \brief Initialize uart 
 **
 ** \return 
 ******************************************************************************/
void UartInit(void)
{
    stc_uart_irq_en_t stc_irq_en;
    stc_uart_irq_cb_t stc_irq_cb;
    stc_uart_config_t stc_uart_cfg;

    DDL_ZERO_STRUCT(stc_irq_en);
    DDL_ZERO_STRUCT(stc_irq_cb);
    DDL_ZERO_STRUCT(stc_uart_cfg);
    Uart_DeInit(UART_COMM_CHANNLE, FALSE);
	
    /* Initialize UART function I/O */
    Gpio_SetFunc_SIN0_0();
    Gpio_SetFunc_SOT0_0();

    /* Initialize UART RX/TX interrupt  */
    stc_irq_en.bTxIrq = FALSE;
    stc_irq_en.bRxIrq = TRUE;
    stc_irq_cb.pfnTxIrqCb = NULL;
    stc_irq_cb.pfnRxIrqCb = Uart_RX_IRQHandler;
    /* Initialize UART RX/TX channel  */
    stc_uart_cfg.enMode = UartNormal;
    stc_uart_cfg.u32BaudRate = 115200;
    stc_uart_cfg.enParity = UartParityNone;
    stc_uart_cfg.enStopBit = UartOneStopBit;
    stc_uart_cfg.enDataLength = UartEightBits;
    stc_uart_cfg.enBitDirection = UartDataLsbFirst;
    stc_uart_cfg.bInvertData = FALSE;
    stc_uart_cfg.bHwFlow = FALSE;
    stc_uart_cfg.bUseExtClk = FALSE;
    stc_uart_cfg.bCarryEnable = FALSE;
    stc_uart_cfg.bCarryPolarity = FALSE;
    stc_uart_cfg.u32CarryFreq = 0;
    stc_uart_cfg.bCompensation = FALSE;
    stc_uart_cfg.u16CompenConf = 0;
    stc_uart_cfg.bIrFunc = FALSE;
    stc_uart_cfg.bCtsWu = FALSE;
    
    stc_uart_cfg.pstcIrqEn = &stc_irq_en;
    stc_uart_cfg.pstcIrqCb = &stc_irq_cb;
    stc_uart_cfg.bTouchNvic = TRUE;
   
    Uart_Init(UART_COMM_CHANNLE,&stc_uart_cfg);

    /* Enable TX function of UART0   */
    Uart_EnableFunc(UART_COMM_CHANNLE, UartTx);
    Uart_EnableFunc(UART_COMM_CHANNLE, UartRx);    

    return;
}


/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
