/******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file rtc_common.c
 **
 ** This source code supports the operation of rtc to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
 
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "rtc_comm.h"
#include "rtc.h"
#include "lcd_show.h"
#include "gpio.h"

//��ǰϵͳʱ��
tSysTime gCurTime={0,20,14,14,3,12,2016}; 
//timeģʽ
static uint8_t sTimeTick=0,STimeMode=0;

//sec handle
static void RTC_OneSecHandle(void)
{
    RTC_GetCurTime(&gCurTime);
    LCD_ShowCurTime(&gCurTime);
}

//init RTC
void RTC_Init(void)
{
    stc_rtc_config_t stc_rtc_cfg;
    stc_rtc_time_t stc_time;
    stc_rtc_irq_en_t stc_irq_en;    
    stc_rtc_irq_cb_t stc_irq_cb;
    
    // Clear structures
    DDL_ZERO_STRUCT(stc_rtc_cfg);
    DDL_ZERO_STRUCT(stc_time);
    DDL_ZERO_STRUCT(stc_irq_en);
    DDL_ZERO_STRUCT(stc_irq_cb);
    
    Gpio_SetFunc_RTCO_0();
    //time
    stc_time.u16Year = 2016;
    stc_time.u8Month = 12;
    stc_time.u8Day = 14;
    stc_time.u8Hour = 12;
    stc_time.u8Minute = 20;
    stc_time.u8Second = 0;
    stc_time.u8DayOfWeek = 3;
//    (void)Rtc_SetDayOfWeek(&stc_time);        // Set Day of the Week in stcRtcTime
    //irq
    stc_irq_en.bOneSecondIrq = TRUE;
    stc_irq_cb.pfnOneSecondIrqCb = &RTC_OneSecHandle;
    //basic    
    stc_rtc_cfg.enClkSel = RtcLSXTClk;
    stc_rtc_cfg.u32ClkPrescaler = RTC_CLOCK_PRES;
    stc_rtc_cfg.bEnSuboutDivider = FALSE;
    stc_rtc_cfg.enDividerRatio = RtcDivRatio1;
    stc_rtc_cfg.enRtccoSel = RtccoOutput1Hz;
    stc_rtc_cfg.pstcTimeDate = &stc_time;
    stc_rtc_cfg.pstcIrqEn = &stc_irq_en;
    stc_rtc_cfg.pstcIrqCb = &stc_irq_cb;
    stc_rtc_cfg.bTouchNvic = TRUE;
    stc_rtc_cfg.bRunNotInit = FALSE;    //Initialize RTC any time  

    Rtc_Init(&stc_rtc_cfg);  
    Rtc_EnableFunc(RtcCount);
    Rtc_DisableIrq(RtcOneSecondIrq);    //disenable one sec irq
    //init time
    RTC_SetCurTime(&gCurTime);
}

//read time
en_result_t RTC_GetCurTime(tSysTime *pTime)
{
    stc_rtc_time_t rtcTime;
        
    DDL_ZERO_STRUCT(*pTime);
    if(Ok == Rtc_ReadDateTime(&rtcTime))
    {
        memcpy((uint8_t*)pTime,(uint8_t*)&rtcTime,sizeof(tSysTime)); 
        
        return Ok;
    }
    
    return Error;
}

//set time
en_result_t RTC_SetCurTime(tSysTime *pTime)
{
    if(Ok == Rtc_SetDateTime((stc_rtc_time_t*)pTime,FALSE,TRUE,TRUE))
    {
        return Ok;
    }
    
    return Error;
}

//start
void LcdRtc_Start(void)
{
    sTimeTick = 0;
    STimeMode = 0;
    LCD_ClearScreen();
    Rtc_EnableIrq(RtcOneSecondIrq);  
}

//stop
void LcdRtc_Stop(void)
{
    Rtc_DisableIrq(RtcOneSecondIrq);    
    LCD_ClearScreen();
}

//��ʾ��ǰʱ��
void LCD_ShowCurTime(tSysTime const *pTime)
{
    sTimeTick++;
    if(sTimeTick >= 6)  
    {
        sTimeTick = 0;
        if(STimeMode==0) 
            STimeMode = 1;
        else
            STimeMode = 0;
    }
    if(STimeMode == 0)   //nMin nSec
    {
        LCD_SetShowValue(0,gCurTime.nMin/10,LcdDotDisenable);
        LCD_SetShowValue(1,gCurTime.nMin%10,LcdDotEnable);
        LCD_SetShowValue(2,gCurTime.nSec/10,LcdDotDisenable);
        LCD_SetShowValue(3,gCurTime.nSec%10,LcdDotDisenable);            
    }
    else        //nHour nMin
    {
        LCD_SetShowValue(0,gCurTime.nHour/10,LcdDotDisenable);
        LCD_SetShowValue(1,gCurTime.nHour%10,LcdDotEnable); 
        LCD_SetShowValue(2,gCurTime.nMin/10,LcdDotDisenable);
        LCD_SetShowValue(3,gCurTime.nMin%10,LcdDotDisenable);   
    }     
}

