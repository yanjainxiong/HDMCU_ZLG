/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file system_tick.c
 **
 ** This source code supports the operation of system tick
 ** 
 ** History:
 **   - 2017-06-27  0.1.0  HeChun         First version.
 **    
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "sys_tick.h"
#define __HCLK                  (4000000)
/*****************************************************************************/
/* Local pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/


/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/
static uint16_t m_u16MilliSecondCount65535 = 0;

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/

/**
 ******************************************************************************
 ** \brief  SysTick_Init
 **
 ** This function Initializes the Systick counter
 **
 ** \param [in]  u32SysTickPerSec   systick counter period
 ** 
 ** \return None 
 ******************************************************************************/
void SysTick_Init(uint32_t u32SysTickPerSec)
{
    /* Configure system ticks */
    SysTick_Config(__HCLK/u32SysTickPerSec);
}
/**
 ******************************************************************************
 ** \brief  SysTick_Handler
 **
 ** This function acts as the systick counter interrupt process, handle the 
 ** system timers in whole system
 **
 ** \param None
 ** 
 ** \return None 
 ******************************************************************************/
void SysTick_Handler(void)
{ 
    m_u16MilliSecondCount65535++;

    return;
}

/*
 ******************************************************************************
Function:    uint8_t TimerMax65535ms(uint16_t *timer, uint16_t timeOutVal)
Description: Check for timeout occurance in mili-seconds (max 65535ms)
Parameter: - uint16_t *timer      -> pointer of timer counter
           - uint16_t timeOutVal  -> timeout value, 
             when timeout value is 0, reset timer
Output: 
Return: -0xff -> TimeOutFlag,  timeout occured and timer updated 
            -0x00 -> NoTimeOutFlag, no timeout yet
 ******************************************************************************
 */
uint8_t SysTick_TimerMax65535ms(uint16_t *timer, uint16_t timeOutVal)
{
    int16_t currentTime, elapsedTime;

     __disable_irq(); 
    currentTime = m_u16MilliSecondCount65535; // Store current system time
     __enable_irq(); 

    if (timeOutVal == RESET_TIMER) 
    {    
        /* Reset Timer to current time*/
        *timer = currentTime; // Store  current system time  to costumer timer variable
        
        return NO_TIME_OUT_FLAG;
    }
    else 
    {
        elapsedTime = currentTime - *timer; // Calculate elapsed time  from reset Timer to now
        
        if(elapsedTime <=0)
        {
            elapsedTime += 65536;   //overflow process
        }
        if (elapsedTime >= timeOutVal) 
        {    
            /* timeout */
            *timer += timeOutVal; // Update new current system time to Timer, Sstart new time count
            return TIME_OUT_FLAG; // Return timeout flag
        } 
        else 
        {
            return NO_TIME_OUT_FLAG; // Not time count
        }
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
