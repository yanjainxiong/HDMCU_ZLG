/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file key.c
 **
 ** This source code supports the operation of key to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
 
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "key.h"
#include "sys_tick.h"
#include "gpio.h"
/*****************************************************************************/
/* Global pre-processor symbols/macros ('#define')							 */
/*****************************************************************************/

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/
stc_key_info_t Key_stcKeyInfo;

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/

/******************************************************************************/
/* Global function prototypes ('extern', definition in C source)              */
/******************************************************************************/

/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/

//key io init 
static void Key_InitIo(void)
{
    Gpio_InitIO(KEY_GPIO_PORT,KEY_GPIO_PIN,GpioDirIn,TRUE,FALSE);
}
    
/**
 ******************************************************************************
 ** \brief get the key value
 **
 ** \param          None
 **
 ** \return         True /False  the key is pressed or Released
 **                    
 ******************************************************************************/
static boolean_t GetKeyValue(void)
{
    if ( 0 == Gpio_GetIO(KEY_GPIO_PORT,KEY_GPIO_PIN))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }   
}

/**
 ******************************************************************************
 ** \brief Init Key related vaue
 **
 ** \param   pstcKeyInfo        the pointer of  the key information
 **
 ** \return   None
 ******************************************************************************/
void Key_Init(stc_key_info_t  *pstcKeyInfo)
{  
    pstcKeyInfo->u16PreventWobbleTime = 10;
    pstcKeyInfo->enKeyValue = NoButton;
    pstcKeyInfo->enKeyState = KeyIdleSta;
    pstcKeyInfo->pfnGetKeyVal = GetKeyValue;
    Key_InitIo();
}

/**
 ******************************************************************************
 ** \brief return the button information which button is specified
 **
 ** \param   pstcKeyInfo       the pointer of  the key information
 **
 ** \return    None
 ******************************************************************************/
void Key_ScanServe(stc_key_info_t *pstcKeyInfo)
{
    
   switch (pstcKeyInfo->enKeyState)
   {
     case KeyIdleSta:
       if ( TRUE == pstcKeyInfo->pfnGetKeyVal())
       {
           pstcKeyInfo->enKeyState = KeyWobSta;
           SysTick_TimerMax65535ms(&pstcKeyInfo->u16KeyTimerCount, 0x0);
       }
       else
       {
          pstcKeyInfo->enKeyValue = NoButton;
       }
       break;
       
     case KeyWobSta:
       if ( TRUE == pstcKeyInfo->pfnGetKeyVal())
       {
           if ( TIME_OUT_FLAG == SysTick_TimerMax65535ms(&pstcKeyInfo->u16KeyTimerCount, pstcKeyInfo->u16PreventWobbleTime))
           {
               pstcKeyInfo->enKeyState = KeyPrsSta;
           }
       }
       else
       {
           pstcKeyInfo->enKeyState = KeyIdleSta;
       }
       break;       
 
     case KeyPrsSta:
       if ( TRUE == pstcKeyInfo->pfnGetKeyVal())
       {
           pstcKeyInfo->enKeyValue = Press;
       }
       else
       {
          pstcKeyInfo->enKeyState = KeyRlsWobSta;
           SysTick_TimerMax65535ms(&pstcKeyInfo->u16KeyTimerCount, 0x0);
       }
       break;

     case KeyRlsWobSta:
       if ( TRUE == pstcKeyInfo->pfnGetKeyVal())
       {
           pstcKeyInfo->enKeyState = KeyPrsSta;
       }
       else
       {
           if ( TIME_OUT_FLAG == SysTick_TimerMax65535ms(&pstcKeyInfo->u16KeyTimerCount, pstcKeyInfo->u16PreventWobbleTime))
           {
               pstcKeyInfo->enKeyState = KeyReleaseSta;
           }
       }
       break;  
       
     case KeyReleaseSta:
       pstcKeyInfo->enKeyValue = Release;
       pstcKeyInfo->enKeyState = KeyIdleSta;
       break;       
       
     default:
            break; 
   }        
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
