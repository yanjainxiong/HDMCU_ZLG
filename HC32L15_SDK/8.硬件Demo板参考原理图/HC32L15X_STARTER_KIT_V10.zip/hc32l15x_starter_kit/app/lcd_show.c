/******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/******************************************************************************/
/** \file lcd_show.c
 **
 ** This source code supports the operation of lcd_show to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/

#include "lcd_show.h"
#include "lcd.h"


//LCD��ӦSEG���
const uint8_t LcdSegNum[] = {0, 1, 2, 3, 4, 5, 6, 9};
// Number 0-9
const uint8_t LcdNumMap[][2] =            
{
    {0x5,0xF},    /* 0 */
    {0x0,0x6},    /* 1 */
    {0x6,0xB},    /* 2 */
    {0x2,0xF},    /* 3 */
    {0x3,0x6},    /* 4 */
    {0x3,0xD},    /* 5 */
    {0x7,0xD},    /* 6 */
    {0x0,0x7},    /* 7 */
    {0x7,0xF},    /* 8 */
    {0x3,0xF},    /* 9 */
    {0x5,0x9}     /* C */      
};

//init lcd 
void LCD_Init(void)
{
    stc_lcd_configtypedef_t stc_lcd_cfg;
    
    DDL_ZERO_STRUCT(stc_lcd_cfg);
    
    /* LCDC output */
    M0P_WSUNIT->CLK_CTL2_f.LCDCKE = 1; //ʹ��LCD clockk

    stc_lcd_cfg.enLcdDisplayClkSel=  LcdClkSelExCrystals ;
    stc_lcd_cfg.enLcdFrameRerateSel = LcdFrameReRateSel256Hz;
    stc_lcd_cfg.enLcdWorkModeSel = Lcd_4Com_1Div4Duty_1Div3bias_TypeA_Max40Seg;  
    
    stc_lcd_cfg.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirContrastSel= LcdContrastSel100per;
    stc_lcd_cfg.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirChargTimeSel = LcdRChargTimSel1Clk;
    stc_lcd_cfg.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirChargModeSel = LcdRChargModeSelLargeCur;   
    stc_lcd_cfg.stcLcdDriveCircuitSel.enLcdDriveCirSel = LcdBiasCircuitSelInRes;
    stc_lcd_cfg.enLcdDrivePowerSel = LcdDrivePowSelNormal;     
    
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE0 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE1 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE2 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE3 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE4 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE5 = TRUE;
    stc_lcd_cfg.stcSeg0_Seg7Config.SEGE6 = TRUE;
    stc_lcd_cfg.stcSeg8_Seg15Config.SEGE9= TRUE;
    
    Lcd_InitConfig(&stc_lcd_cfg);
    Lcd_Cmd(ENABLE);
}

/*
 *index: 0-3
 *value: 0-9
 *dot: С����  
*/
en_result_t LCD_SetShowValue(uint8_t index,uint8_t value,LcdDotFun dot)
{
    if((index>3) | (value>10))
        return Error;
    
    //number
    if(dot == LcdDotEnable)      //dot
        LCD_WriteDdramIndexByte(LcdSegNum[index*2], LcdNumMap[value][0]|0x8);
    else
        LCD_WriteDdramIndexByte(LcdSegNum[index*2], LcdNumMap[value][0]);
    LCD_WriteDdramIndexByte(LcdSegNum[index*2+1],LcdNumMap[value][1]);
    
    return Ok;
}

//full show
void LCD_FullScreen(void)
{
    Lcd_FullWrite();
}

//clear show
void LCD_ClearScreen(void)
{
    Lcd_FullClear();
}
  









