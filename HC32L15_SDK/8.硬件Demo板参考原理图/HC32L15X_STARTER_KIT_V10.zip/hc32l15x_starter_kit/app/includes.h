#ifndef __INCLUDES_H_
#define __INCLUDES_H_


#ifdef __cplusplus 
extern "C"
{
#endif


#include "sys_tick.h"
#include "temp_adc.h"
#include "key.h"
#include "led_buzz.h"
#include "lcd_show.h"
#include "rtc_comm.h"
#include "uart_comm.h"
#include "i2c_eeprom.h"
#include "func_item.h"
#include "com_app.h"


#ifdef __cplusplus
}
#endif


#endif

