/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file com_app.c
 **
 ** This source code supports the operation of com_app to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
 
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "com_app.h"
#include "uart_comm.h"
#include "func_item.h"

/*****************************************************************************/
/* Local pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/
const uint8_t  ItemWriteAddrStart = 51;
const uint8_t  ItemWriteMax = 10;

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/
static uint8_t VendorInf[][80] = 
{
  {"********************************************************************* \r\n\0"},
  {"*                           HC32L15 Start Kit                       * \r\n\0"},
  {"*                            Test Procedure                         * \r\n\0"},
  {"*                                                                   * \r\n\0"}
};

uint8_t NoteInf[][80] =
{
  {"*                                                                   * \r\n"},
  {"*   Key in the option number                                        * \r\n"},
  {"*   Press 'Enter' key to run the procedures                         * \r\n"},
  {"*                                                                   * \r\n"},
  {"********************************************************************* \r\n\0"},
};
uint8_t TestItem[][80] = 
{
  {"*  00:  UART (CMSIS DAP Port) Test                 [........]       * \r\n\0"},
  {"*  01:  Sub Clock Test                             [........]       * \r\n\0"},
  {"*  02:  LED Test                                   [........]       * \r\n\0"},
  {"*  03:  USER Key Test                              [........]       * \r\n\0"},
  {"*  04:  Buzz Test                                  [........]       * \r\n\0"},
  {"*  05:  Temperature Sensor Test                    [........]       * \r\n\0"},    
  {"*  06:  EEPROM Test                                [........]       * \r\n\0"},
  {"*  07:  LCD And RTC Test                           [........]       * \r\n\0"},
};  

                           
uint8_t ItemWrPara1[10] = "[ Tested ]";
uint8_t ItemWrPara2[10] = "[   OK   ]";
uint8_t ItemWrPara3[10] = "[ Failed ]";

uint8_t RgbLedCueInfo[]  = "  Watch the LED (LED3), brightness will change  \r\n\0";
uint8_t KeyCueInfo[]     = "  Press the USER key to return      \r\n\0";
uint8_t OpSenCueInfo[]   = "  Cover the Q3, The display value will be changed       \r\n\0";

stcSysRun_t stcSysRun;

void ComPortInit(void)
{
    uint8_t i = 0;
    
    UartInit();
    
    stcSysRun.MenuItemNum = 0xFF;
    
    // Display menu item 0
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara2;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = PortTestHandle;
    stcSysRun.stcMenuItem[i++].pFunReturnMain = PortTestReturn; 

     // Display menu item 1
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara2;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = SubClockTestHandle;
    stcSysRun.stcMenuItem[i++].pFunReturnMain = SubClockTestReturn; 
    
    // Display menu item 2
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = RgbLedCueInfo;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara1;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = RgbLedTestHandle; 
    stcSysRun.stcMenuItem[i++].pFunReturnMain = RgbLedTestReturn;

    // Display menu item 3
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = KeyCueInfo;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara2;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = KeyTestHandle;  
    stcSysRun.stcMenuItem[i++].pFunReturnMain = KeyTestReturn; 

    // Display menu item 4
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara1;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = BuzzTestHandle;  
    stcSysRun.stcMenuItem[i++].pFunReturnMain = BuzzTestReturn; 
    
    // Display menu item 5
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara1;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = TempAdcTestHandle;  
    stcSysRun.stcMenuItem[i++].pFunReturnMain = TempAdcTestReturn;   

    // Display menu item 6
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara2;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = EepromTestHandle;  
    stcSysRun.stcMenuItem[i++].pFunReturnMain = EepromTestReturn; 
    
    // Display menu item 7
    stcSysRun.stcMenuItem[i].pMenuDisplayInfo = &TestItem[i][0];
    stcSysRun.stcMenuItem[i].pMenuCueInfo     = NULL;
    stcSysRun.stcMenuItem[i].pMenuItemWrite   = ItemWrPara1;
    stcSysRun.stcMenuItem[i].pFunMenuItem     = LcdRtcTestHandle;  
    stcSysRun.stcMenuItem[i++].pFunReturnMain = LcdRtcTestReturn; 
    
    return;
}

void WriteItem(uint8_t *pAddr, uint8_t *pData)
{
    uint8_t cnt;
    if ( NULL == pData )
    {
        return;
    }  
    for (cnt=0; cnt<ItemWriteMax; cnt++)
    {
         *(pAddr+ItemWriteAddrStart+cnt) = *pData++;
    }
    
    return;
}

void DisplayVendor(void)
{
    uint8_t cnt;  
    /* Display the welcome interface */
    for (cnt=0; cnt< 4; cnt++)
    UartWriteString(&VendorInf[cnt][0]);
    
    /* Display the test item interface */
    for (cnt = 0; cnt < MENUITEMMAX; cnt++)
    {
        UartWriteString(stcSysRun.stcMenuItem[cnt].pMenuDisplayInfo);
    }
        
    /* Display the end welcome interface */
    for (cnt=0; cnt< 5; cnt++)
    UartWriteString(&NoteInf[cnt][0]);
    UartWriteString("<_ \0");
   
    return;
}

void RunMenuItem(void)
{
    uint8_t ItemID = 0x0;
 
    if ( (TRUE != stcSysRun.EnableItem) || (stcSysRun.MenuItemNum >= MENUITEMMAX))
    {
        stcSysRun.MenuItemNum = 0xFF;
        return;
    }

    ItemID = stcSysRun.MenuItemNum;
    UartWriteString(stcSysRun.stcMenuItem[ItemID].pMenuCueInfo);

    if ( NULL != stcSysRun.stcMenuItem[ItemID].pFunReturnMain)
    {
        while ( FALSE == stcSysRun.stcMenuItem[ItemID].pFunReturnMain())
        {
            if ( NULL != stcSysRun.stcMenuItem[ItemID].pFunMenuItem)
            {
                stcSysRun.stcMenuItem[ItemID].pFunMenuItem();
            }
            UartRxHandle();
        }  
    }
    
    WriteItem(stcSysRun.stcMenuItem[ItemID].pMenuDisplayInfo,
    stcSysRun.stcMenuItem[ItemID].pMenuItemWrite);
    DisplayVendor();
    stcSysRun.EnableItem = FALSE;

    return;
}
 
void GetMainItemValue(void)
{
    if ( (TRUE == stcSysRun.UartRxFlag) && (TRUE == stcSysRun.UartRxValid ))
    {
        if ( stcSysRun.UartRxData < MENUITEMMAX )
        {
            stcSysRun.MenuItemNum = stcSysRun.UartRxData;
            stcSysRun.EnableItem = TRUE;
        }
    }
    else if ( (TRUE == stcSysRun.UartRxFlag) && (FALSE == stcSysRun.UartRxValid ))
    {
        DisplayVendor();
    }
    else
    {
        ;
    }

    stcSysRun.UartRxFlag = FALSE;

    return;
}
           
/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
