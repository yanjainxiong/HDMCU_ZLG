/******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file temp_adc.c
 **
 ** This source code supports the operation of temp_adc to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "temp_adc.h"
#include "adc.h"
#include "lcd_show.h"
#include "gpio.h"

/******************************************************************************/
/* Global variable definitions (declared in header file with 'extern')        */
/******************************************************************************/

/******************************************************************************/
/* Local type definitions ('typedef')                                         */
/******************************************************************************/

/******************************************************************************/
/* Local function prototypes ('static')                                       */
/******************************************************************************/

/******************************************************************************/
/* Local variable definitions ('static')                                      */
/******************************************************************************/


/**
 ******************************************************************************
 ** \brief Initialisation of a ADC module.
 **
 ** \param [in]  None
 **
 ** \retval Ok          Initializiation of Adc module successfully done.
 ** \retval ErrorInvalidParameter  pstcConfig == NULL,
 **                                parameter out of range
 ******************************************************************************/
en_result_t TempAdc_Init(void)
{    
    /* Initial Adc functions    */
    stc_adc_confgtypedef_t stc_adc_cfg;
    
    DDL_ZERO_STRUCT(stc_adc_cfg);
    
    Gpio_SetAnalog(TEMP_ADC_PORT,TEMP_ADC_PIN,TRUE);
    stc_adc_cfg.enAdcSampFreqSel = SampFreqSysTDiv4;
    stc_adc_cfg.enAdcSampTimeSel = AdcSmapTim_6Clk;
    stc_adc_cfg.enAdcSampModeSel = AdcContinSamp;
    stc_adc_cfg.enAdcRefVolSel = RefVolSelInBgr2_5;
    stc_adc_cfg.enAdcSampChSel = TEMP_ADC_CHANNEL;
    stc_adc_cfg.enAdcInSignalAmpEn = AdcInSignalAmpDisable;
    stc_adc_cfg.enAdcResultAlign = AdcResultRightAlign;
    stc_adc_cfg.pfnAdcConvIrqCallback = NULL;
    stc_adc_cfg.bTouchNvic = AdcIrqDisable;
       
    if (Ok == Adc_InitConfig(&stc_adc_cfg))    // Init ADC
    {
        return Ok;  //Initial success 
    }

    return ErrorInvalidParameter;
}

/**
 ******************************************************************************
 ** \brief  ADC scan irq callback function
 **
 ** \param  pu32AdcArgument             Pointer to ADC FIFO value
 **
 ** \retval void
 **
 ******************************************************************************/
float TempAdc_GetVol(void)      //mv
{
    uint8_t covCnt;
    float voltage = 0;
    uint32_t temperature = 0;
    
    covCnt = 10;
    Adc_ConvCmd(ENABLE);
    Adc_ConvStart(AdcSampStart);
    
    while(covCnt--)   
    {
        while(Adc_GetConvItFlagState()!=AdcCnvFinishITFlag);
        Adc_ClearConvIrqFlag();
        temperature += Adc_GetConversionValue();
    }
    Adc_ConvCmd(AdcSampOff);
    voltage = (float)(temperature/10)*2500/4096;

    return voltage;
}

//get temp value
uint16_t TempAdc_GetValue(void)
{
    float vol;
    uint16_t temp;
    
    vol = TempAdc_GetVol();
    //ȡС�����һλ���¶�ֵ����10��
    temp = (uint16_t)((vol-MCP9700A_OFFSET_VOL)/MCP9700A_TEMP_COEFF*10);
    
    return temp;         
}

//��ʾ�¶�-tpΪ����10�¶�ֵ
void LcdShoTemperature(uint16_t tp)
{
    LCD_SetShowValue(0,tp/100,LcdDotDisenable);
    LCD_SetShowValue(1,tp%100/10,LcdDotDisenable);
    LCD_SetShowValue(2,tp%10,LcdDotEnable);
    LCD_SetShowValue(3,10,LcdDotDisenable);   
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
