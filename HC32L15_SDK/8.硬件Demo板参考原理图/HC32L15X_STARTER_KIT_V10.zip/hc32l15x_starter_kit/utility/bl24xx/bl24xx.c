/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/

/******************************************************************************/
/** \file i2c_polling_Bl24xx.c
 **
 ** A detailed description is available at 
 ** @link I2cBl24xxGroup Module description @endlink
 **
 ** History:
 **   - 2017-06-27  0.1  HeChun  First version.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "bl24xx.h"
#include "i2c.h"
#include "gpio.h"

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/
/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/
/*****************************************************************************/
/* Local variable definitions ('static')                                     */
/*****************************************************************************/

/**
 ******************************************************************************
 ** \brief   Check the error status of I2C
 **
 ** \retval  TRUE                       I2C error occurs 
 ** \retval  FALSE                      No error
 **                                     
 ******************************************************************************/
static boolean_t I2cCheckErrorStatus(void)
{    
    if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cBusErr))
    {
        return TRUE; /* Bus error occurs? */
    }
    
    if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cOverrunError))
    {
        return TRUE; /* Overrun error occurs? */
    }
    
    return FALSE;
}


/**
 ******************************************************************************
 ** \brief   Generate I2C start signal and send device address
 **
 ** \param   [in]  u8DevAddr          Device address
 **
 ** \retval  Ok                       I2C start normally
 ** \retval  ErrorTimeout             I2C timeout 
 ** \retval  Error                    Other errors
 **                                     
 ******************************************************************************/
static en_result_t I2cStart(uint8_t u8DevAddr)
{
    /* Prepare I2C device address */
    I2c_SendData(BL24XX_COMM_CHANNEL, u8DevAddr);
    
    /* Enable ACK */
    I2c_ConfigAck(BL24XX_COMM_CHANNEL, I2cAck);
    
    /* Generate I2C start signal */
    if(Ok != I2c_GenerateStart(BL24XX_COMM_CHANNEL))
    {
        return ErrorTimeout; /* Timeout or other error */
    }

    /* Wait until data transfer finish */
    while(1)
    {
        if(TRUE != I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq))
        {
            break;
        }
    }
    
    /* Check ACK */
    if(I2cNAck == I2c_GetAck(BL24XX_COMM_CHANNEL))
    {
        return Error;   /* NACK */
    }
    
    /* Check error status of I2C */
    if(TRUE == I2cCheckErrorStatus())
    {
        return Error;
    }
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Sene I2C data
 **
 ** \param   [in]  pu8Data            Pointer to data address
 ** \param   [in]  u8Size             Data size
 **
 ** \retval  Ok                       I2C data send normally
 ** \retval  Error                    I2C NACK, bus error, overrun error
 **                                     
 ******************************************************************************/
static en_result_t I2cSendData(uint8_t* pu8Data, uint8_t u8Size) 
{
    uint8_t i = 0;
    
    for(i=0;i<u8Size;i++)
    {
      
        /* Transmit the data */
        I2c_SendData(BL24XX_COMM_CHANNEL, pu8Data[i]);
        I2c_ClrStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq);
        
        /* Wait for end of transmission */
			  while(1)
        {
            if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq))
            {
                break;
            }
        }
				/* Check until TX finish */
        while(1)
        {
            if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cTxEmpty))
            {
                break;
            }
        }
       
        /* Check ACK */
        if(I2cNAck == I2c_GetAck(BL24XX_COMM_CHANNEL))
        {
            return Error;   /* NACK */
        }
        
        if(TRUE == I2cCheckErrorStatus())
        {
            return Error;
        }
    }
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Read I2C data
 **
 ** \param   [out]  pRxData            Pointer to data address
 ** \param   [in]   u8Size             Data size
 **
 ** \retval  Ok                       I2C read normally
 ** \retval  Error                    I2C NACK, bus error, overrun error
 **                                     
 ******************************************************************************/
static en_result_t I2cRead(uint8_t *pRxData, uint8_t u8Size)
{
    uint8_t u8i = 0;

    while(u8i < u8Size)
    { 

				
        I2c_ClrStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq);
				
			  if(u8i == u8Size-1)
        {
            I2c_ConfigAck(BL24XX_COMM_CHANNEL, I2cNAck); /* Last byte send a NACK */
        }
        else
        {
            I2c_ConfigAck(BL24XX_COMM_CHANNEL, I2cAck);
        }
				
        /* Wait for the receive data */
        while(1)
        {
            if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq))
            {
                break;
            }
        }
        
        
        /* Clear interrupt flag and receive data to RX buffer */
        
        
        /* Wait for the receive data */
        while(1)
        {
            if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cRxFull))
            {
                break;
            }
        }
         
        /* Check error status of I2C */
        if(TRUE == I2cCheckErrorStatus())
        {
            return Error;
        }
        
        pRxData[u8i++] = I2c_ReceiveData(BL24XX_COMM_CHANNEL);
				
				
    }
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Generate I2C stop signal
 **
 ** \retval  Ok                       I2C stop normally
 ** \retval  ErrorTimeout             I2C timeout 
 ** \retval  Error                    Other errors
 **                                     
 ******************************************************************************/
static en_result_t I2cStop(void)
{
    /* Generate I2C start signal */
    if(Ok != I2c_GenerateStop(BL24XX_COMM_CHANNEL))
    {
        return ErrorTimeout; /* Timeout or other error */
    }
    /* Clear Stop condition flag */
    while(1)
    {
        if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cStopDetect))
        {
            break;
        }
    }
   
    if(TRUE == I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cBusErr))
    {
        return Error;
    }
   
    I2c_ClrStatus(BL24XX_COMM_CHANNEL, I2cStopDetect);
    I2c_ClrStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq);
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Initialize Bl24xx
 **
 ** \retval  Ok                       I2C start normally
 ** \retval  Error                    Other errors
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_Init(void)
{
    stc_i2c_config_t stc_i2c_cfg;
    
    DDL_ZERO_STRUCT(stc_i2c_cfg);
    
    Gpio_SetFunc_SCK5_2();
    Gpio_SetFunc_SOT5_2();
    
	  I2c_DeInit(BL24XX_COMM_CHANNEL);
    stc_i2c_cfg.enMsMode = I2cMaster;
    stc_i2c_cfg.u32BaudRate = 50000;    //50k HZ
    stc_i2c_cfg.u8SlaveAddr = 0;
    stc_i2c_cfg.bWaitSelection = FALSE;
    stc_i2c_cfg.pstcIrqCb = NULL;
    stc_i2c_cfg.pstcIrqEn = NULL;
    stc_i2c_cfg.bTouchNvic = FALSE;
  
    if(Ok != I2c_Init(BL24XX_COMM_CHANNEL, &stc_i2c_cfg))
    {
        return Error;
    }
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Write byte at a certain address of Bl24xx
 **
 ** \param  [in] u8DevAddr   7-bit device address
 ** \param  [in] u16Addr     Data address
 ** \param  [in] u8Data      Data byte
 **
 ** \retval  Ok                       Write byte normally
 ** \retval  Error                    Write byte failed
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_ByteWrite(uint8_t u8DevAddr, uint16_t u16Addr, EepromWordAddr uType, uint8_t u8Data)
{
    uint8_t au8TempData[2];
  
    if(Ok != I2cStart((u8DevAddr<<1) | 0u))
    {
        return Error;
    }
    
    /* Send page address */
    if(uType == BL24XX_ADDR_ONE_LENGTH)
    {
        au8TempData[0] = u16Addr & 0x00FFu;
    }
    else
    {
        au8TempData[0] = (u16Addr & 0xFF00u) >> 8;
        au8TempData[1] = u16Addr & 0x00FFu;
    }
    
    if(Ok != I2cSendData(au8TempData, uType))
    {
        return Error;
    }
    
    /* Send data */
    if(Ok != I2cSendData(&u8Data, 1))
    {
        return Error;
    }
    
    if(Ok != I2cStop())
    {
        return Error;
    }
    
    return Ok;
}


/**
 ******************************************************************************
 ** \brief   Write a page bytes at a page address of Bl24xx
 **
 ** \param  u8DevAddr        7-bit device address
 ** \param  [in] u16PageAddr Random addess within EEPROM memory
 ** \param  [in] pu8Data     Pointer to data array
 ** \param  [in] u8Size      Data size (shoudl be less than page size)
 **
 ** \retval  Ok                       Write page normally
 ** \retval  Error                    Write page failed
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_PageWrite(uint8_t u8DevAddr, uint16_t u16PageAddr, EepromWordAddr uType, uint8_t* pu8Data, uint8_t u8Size)
{
    uint8_t au8TempData[2];
    
    if(Ok != I2cStart((u8DevAddr<<1) | 0u))
    {
        return Error;
    }
    
    /* Send page address */
    if(uType == BL24XX_ADDR_ONE_LENGTH)
    {
        au8TempData[0] = u16PageAddr & 0x00FFu;
    }
    else
    {
        au8TempData[0] = (u16PageAddr & 0xFF00u) >> 8;
        au8TempData[1] = u16PageAddr & 0x00FFu;
    }
    
    if(Ok != I2cSendData(au8TempData, uType))
    {
        return Error;
    }
    
    /* Send data */
    if(Ok != I2cSendData(pu8Data, u8Size))
    {
        return Error;
    }
    
    if(Ok != I2cStop())
    {
        return Error;
    }
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Read the data of current data address of Bl24xx
 **
 ** \param  [in]  u8DevAddr  7-bit device address
 ** \param  [out] pu8CurData Pointer to the data read
 **
 ** \retval  Ok                       Read data normally
 ** \retval  Error                    Read data failed
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_CurrentAddrRead(uint8_t u8DevAddr, uint8_t* pu8CurData)
{   
    if(Ok != I2cStart((u8DevAddr<<1)  | 1u))
    {
        return Error;
    }
    
    I2cRead(pu8CurData, 1);
    
    if(Ok != I2cStop())
    {
        return Error;
    }
    
    return Ok;
}

/**
 ******************************************************************************
 ** \brief   Read a byte data of ramdon data address of Bl24xx
 **
 ** \param  [in] u8DevAddr  7-bit device address
 ** \param  [in] u16Addr     Data address
 ** \param  [out] pu8Data    Pointer to the data read
 **
 ** \retval  Ok                       Read data normally
 ** \retval  Error                    Read data failed
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_RandomRead(uint8_t u8DevAddr, uint16_t u16Addr, EepromWordAddr uType, uint8_t* pu8Data, uint8_t u8Size)
{
  /*addr temp*/
  uint8_t au8TempData[2];
	
  /* Send start with write flag */
  I2c_SendData(BL24XX_COMM_CHANNEL,((u8DevAddr<<1)  | 0u));
  if(Ok != I2c_GenerateStart(BL24XX_COMM_CHANNEL))
  {
      return ErrorTimeout; /* Timeout or other error */
  }
	
  /* Send address */
  if(uType == BL24XX_ADDR_ONE_LENGTH)
  {
       au8TempData[0] = u16Addr & 0x00FFu;
  }
  else
  {
      au8TempData[0] = (u16Addr & 0xFF00u) >> 8;
      au8TempData[1] = u16Addr & 0x00FFu;
  }
	
  if(Ok != I2cSendData(au8TempData, uType))
  {
      return Error;
  }
	
  I2c_SendData(BL24XX_COMM_CHANNEL, ((u8DevAddr<<1)  | 1u));
  I2c_GenerateStart(BL24XX_COMM_CHANNEL);
  while(TRUE != I2c_GetStatus(BL24XX_COMM_CHANNEL, I2cRxTxIrq));

  I2cRead(pu8Data, u8Size);
	
  I2cStop();
  
  return Ok;	
}

/**
 ******************************************************************************
 ** \brief   Read data bytes following by random read or current address read
 **
 ** \param  [in]  u8DevAddr   7-bit device address
 ** \param  [out] pu8Data     Pointer to the data read
 ** \param  [in]  u8Size      Data size
 **
 ** \retval  Ok                       Read data normally
 ** \retval  Error                    Read data failed
 **                                     
 ******************************************************************************/
en_result_t Bl24xx_SequentialRead(uint8_t u8DevAddr, uint8_t* pu8Data, uint8_t u8Size)
{
    if(Ok != I2cStart((u8DevAddr<<1)  | 1u))
    {
        return Error;
    }
    
    if(Ok != I2cRead(pu8Data, u8Size))
    {
        return Error;
    }
    
    if(Ok != I2cStop())
    {
        return Error;
    }
    
    return Ok;
}


/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
