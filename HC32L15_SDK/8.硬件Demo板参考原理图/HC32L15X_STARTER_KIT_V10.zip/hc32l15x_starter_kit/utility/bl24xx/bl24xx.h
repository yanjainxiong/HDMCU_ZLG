/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file i2c_bl24xx.h
 **
 ** BL24CXX driver file header file
 **
 ** The BL24xx is tested in the example, make following pin connection first.
 **
 **
 ** History:
 **   - 2017-06-27  1.0  HeChun        First release version.
 **
 ******************************************************************************/
#ifndef __BL_24XX__H_
#define __BL_24XX__H_

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"
   
      
/******************************************************************************
 * Global definitions
 ******************************************************************************/


/*i2c channel*/
#define BL24XX_COMM_CHANNEL           I2CCH5

/*address length*/
typedef enum
{
    BL24XX_ADDR_ONE_LENGTH = 1,
    BL24XX_ADDR_TWO_LENGTH = 2
}EepromWordAddr;


/*---------------------------------------------------------------------------*/
/* function prototypes                                                       */
/*---------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
    
en_result_t Bl24xx_Init(void); 
en_result_t Bl24xx_ByteWrite(uint8_t u8DevAddr, uint16_t u16Addr, EepromWordAddr uType, uint8_t u8Data);
en_result_t Bl24xx_PageWrite(uint8_t u8DevAddr, uint16_t u16PageAddr, EepromWordAddr uType, uint8_t* pu8Data, uint8_t u8Size);
en_result_t Bl24xx_CurrentAddrRead(uint8_t u8DevAddr, uint8_t* pu8CurData);
en_result_t Bl24xx_RandomRead(uint8_t u8DevAddr, uint16_t u16Addr, EepromWordAddr uType, uint8_t* pu8Data, uint8_t u8Size);
en_result_t Bl24xx_SequentialRead(uint8_t u8DevAddr, uint8_t* pu8Data, uint8_t u8Size);

#ifdef __cplusplus
}
#endif


#endif //  _I2C_Bl24xxXX_H_

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
