/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for adc single sample demonstration.
 **        Get more details from readme text.
 **
 **   - 2016-02-16  1.0  QCP First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "adc.h"
#include "gpio.h"

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define T1_PORT             (6)
#define T1_PIN              (2)

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')        
 ******************************************************************************/
uint16_t u16AdcValue = 0;


/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 ******************************************************************************
 ** \brief  ADC interrupt Handler
 **        
 ** \retval NONE
 **
 ******************************************************************************/
void ADC_ITConvHandler(void)
{
    /* User interrupt service routine. */    
}

/**
 ******************************************************************************
 ** \brief  The ADC conversion GPIO initialization configuration
 **        
 **
 ** \retval en_result_t     return value, if needed
 **
 **
 ******************************************************************************/
en_result_t Adc_GpioConfig(void)
{
    /* The function returns the state. */
    en_result_t  enresult =  Error;

    /* Set the I/O to analog input port. */
    enresult = Gpio_SetAnalog( T1_PORT, T1_PIN, TRUE);
    /* Exception handling. */
    if(enresult != Ok)
    {
       return enresult;
    }
    
    /* Initializes the I/O port. */
    enresult = Gpio_InitIO( T1_PORT, T1_PIN, GpioDirIn, FALSE, FALSE);
    
    return enresult;
}


/**
 ******************************************************************************
 ** \brief  The ADC conversion initialization configuration
 **        
 **
 ** \retval en_result_t     return value, if needed
 **
 **
 ******************************************************************************/
en_result_t Adc_InitConvConfig(void)
{
    /* The ADC conversion initialization configuration instance. */
    stc_adc_confgtypedef_t  AdcInitConfig;
    /* The function returns the state. */
    en_result_t  enresult =  Error;
     
    /* Clear structure data. */
    ddl_memclr(&AdcInitConfig,sizeof(AdcInitConfig));

    /* The ADC clock selection,PCKL0. */
    AdcInitConfig.enAdcSampFreqSel = SampFreqSysTDiv1;
    /* Choose the ADC sampling clock cycle. */
    AdcInitConfig.enAdcSampTimeSel = AdcSmapTim_6Clk;
    /* The ADC mode selection. */
    AdcInitConfig.enAdcSampModeSel = AdcSingleSmple;
    /* The ADC reference voltage. */
    AdcInitConfig.enAdcRefVolSel = RefVolSelInBgr2_5;
    /* The ADC sampling channel selection. */
    AdcInitConfig.enAdcSampChSel = SelExInputCH6;
    /* The ADC signal amplification. */
    AdcInitConfig.enAdcInSignalAmpEn = AdcInSignalAmpDisable;
    /* The ADC sampling data alignment. */
    AdcInitConfig.enAdcResultAlign = AdcResultRightAlign;
    
    /* Pointer to ADC CONV interrupt callback function. */ 
    AdcInitConfig.pfnAdcConvIrqCallback = ADC_ITConvHandler;
    /* TRUE: enable MVIC, FALSE: don't enable NVIC. */
    AdcInitConfig.bTouchNvic = FALSE;
    
    /* The ADC conversion initialization configuration. */
    enresult = Adc_InitConfig(&AdcInitConfig);
    
    /* Only the ADC range CMP ENABLE OR DISABLE. */
    Adc_RangCmpCmd(DISABLE);
    /* Only the ADC CONV IT ENABLE OR DISABLE. */
    Adc_ConvItCmd(DISABLE);
    
    return enresult;
}

/**
 ******************************************************************************
 ** \brief The BGR  ENABLE
 **        
 **
 ** \retval NONE
 **
 **
 ******************************************************************************/
void Adc_BgrEnable(void)
{
    /* The BGR  ENABLE. */
    M0P_WSUNIT->BGR_CTL_f.BGR_EN = TRUE;
    /* Waiting for BGR stability. */
    delay1ms(10);    
}

/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \retval uint32_t    return value, if needed
 **
 **
 ******************************************************************************/
int32_t main(void)
{    
    /* Lhe system clock configuration . */
    
    /* GPIO configuration A06=P62,. */
    Adc_GpioConfig();
    /* The ADC conversion initialization configuration. */
    Adc_InitConvConfig();
    /* The ADC conversion initialization configuration. */
    Adc_BgrEnable();
    /* Only the ADC conversion ENABLE OR DISABLE. */
    Adc_ConvCmd(ENABLE);
    /* Waiting for ADC stability. */
    delay1ms(1); 
    /* The ADC conversion Start. */
    Adc_ConvStart(ENABLE);
            
    while (1)
    {
        /* Waiting for the results ADC change. */
        if(Adc_GetConvItFlagState())
        {          
            /* Clear ADC conv IT Flag. */
            Adc_ClearConvIrqFlag();
            /* To obtain the ADC conversion value. */
            u16AdcValue = Adc_GetConversionValue();
          
        }

    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/

