/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** This example demonstrates the calendar funciton of Real Time Clock. Every
 ** second the time and date are read, and when the alarm occurs, a LDE will
 ** start blinking.
 **
 **   - 2016-11-1  1.0   First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "ddl.h"
#include "rtc.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')                            
 ******************************************************************************/
#define DEBUG_PRINT 1
/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')        
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')                                         
 ******************************************************************************/
typedef enum en_dump_type
{
    DumpDateTime,
    DumpAlarmTime,
}en_dump_type_t;
/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
static uint32_t u32IntHalfSec = 0;
static uint8_t  u8AlarmOccur = 0;
static uint8_t  u8IntSec = 0;
static uint8_t  u8BlinkFlag = 0;
static uint8_t  u8BlinkPolling = 0;

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')                             
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

static void DisableAlarm(void)
{
    Rtc_DisableFunc(RtcAlarmSecEn);
    Rtc_DisableFunc(RtcAlarmMinEn);
    Rtc_DisableFunc(RtcAlarmHourEn);
    Rtc_DisableFunc(RtcAlarmDayEn);
    Rtc_DisableFunc(RtcAlarmMonthEn);
    Rtc_DisableFunc(RtcAlarmYearEn);
}
static void EnableAlarm(void)
{
    Rtc_EnableFunc(RtcAlarmSecEn);
    Rtc_EnableFunc(RtcAlarmMinEn);
    Rtc_EnableFunc(RtcAlarmHourEn);
    Rtc_EnableFunc(RtcAlarmDayEn);
    Rtc_EnableFunc(RtcAlarmMonthEn);
    Rtc_EnableFunc(RtcAlarmYearEn);
}

/**
 ******************************************************************************
 ** \brief Initializatio GPIO
 **
 ******************************************************************************/
static void PortInit(void)
{
   //Gpio1pin_InitOut(GPIO1PIN_P61, Gpio1pin_InitVal(0u));
}

/**
 ******************************************************************************
 ** \brief Set port for LED
 **
 ******************************************************************************/
static void LedPolling(void)
{
    if(u8BlinkFlag == 1)
    {
        if(u32IntHalfSec == 1)
        {
            //Gpio1pin_Put(GPIO1PIN_P61, u8BlinkPolling);
            u8BlinkPolling = ~u8BlinkPolling;
            u32IntHalfSec = 0;
        }
    }
}

/**
 ******************************************************************************
 ** \brief Alarm Interrupt
 **
 ******************************************************************************/
static void SampleRtcAlarmCb(void)
{
    u8AlarmOccur = 1;
    u8BlinkFlag = 1;
    DisableAlarm();
}

/**
 ******************************************************************************
 ** \brief 0.5-Second Interrupt
 **
 ******************************************************************************/
static void SampleRtcHalfSencondCb(void)
{
    u32IntHalfSec = 1;
}

/**
 ******************************************************************************
 ** \brief One Second Interrupt
 **
 ******************************************************************************/
static void SampleRtcOneSencondCb(void)
{
    // Set the one second interruption flag
    u8IntSec = 1;
}

#ifdef DEBUG_PRINT
static void dumpTime(void* vtime, en_dump_type_t type)
{
    ASSERT(NULL != vtime);

    if(DumpDateTime == type)
    {
        stc_rtc_time_t* pstcTime = (stc_rtc_time_t* )vtime;
        // Print RTC to console
        printf("%04d/%02d/%02d %02d:%02d:%02d ",
                                               pstcTime->u16Year,
                                               pstcTime->u8Month,
                                               pstcTime->u8Day,
                                               pstcTime->u8Hour,
                                               pstcTime->u8Minute,
                                               pstcTime->u8Second);

        switch (pstcTime->u8DayOfWeek)
        {
            case RtcSunday:
                printf("Sunday\n");
                break;
            case RtcMonday:
                printf("Monday\n");
                break;
            case RtcTuesday:
                printf("Tuesday\n");
                break;
            case RtcWednesday:
                printf("Wednesday\n");
                break;
            case RtcThursday:
                printf("Thursday\n");
                break;
            case RtcFriday:
                printf("Friday\n");
                break;
            case RtcSaturday:
                printf("Saturday\n");
                break;
            default:
                break;
        }
    }
    else
    {
        stc_rtc_alarm_t* pstcTime = (stc_rtc_alarm_t* )vtime;
        // Print RTC to console
        printf("%04d/%02d/%02d %02d:%02d:%02d ",
                                               pstcTime->u16Year,
                                               pstcTime->u8Month,
                                               pstcTime->u8Day,
                                               pstcTime->u8Hour,
                                               pstcTime->u8Minute,
                                               pstcTime->u8Second);
        printf("Alarm\n");
    }
        
}
#endif

/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample
 **
 ******************************************************************************/
int32_t main(void)
{
    
    en_result_t enResult;
    stc_rtc_config_t stcRtcConfig;
    stc_rtc_irq_en_t stcIrqEn;
    stc_rtc_irq_cb_t stcIrqCb;
    stc_rtc_time_t   stcTimeDate;
    stc_rtc_alarm_t  stcAlarm;
    stc_clk_config_t stcClkCfg;
    
    // Clear structures
    DDL_ZERO_STRUCT(stcRtcConfig);
    DDL_ZERO_STRUCT(stcTimeDate);
    DDL_ZERO_STRUCT(stcAlarm);
    DDL_ZERO_STRUCT(stcIrqEn);
    DDL_ZERO_STRUCT(stcIrqCb);
    DDL_ZERO_STRUCT(stcClkCfg);

    // Initialize GPIO for LED
    PortInit();

    //config clock
    stcClkCfg.enBaseClkDiv = ClkBaseDiv1;
    stcClkCfg.enAPB1Div = ClkApb1Div1;
    stcClkCfg.enclkWaitMain = ClkCswtMain1ms;
    stcClkCfg.enAPB0Div = ClkApb0Div1;
    stcClkCfg.enclkWaitSub = ClkCswtSub256ms;
    Clk_Init(&stcClkCfg);
    Clk_Enable(ClkHSXT, TRUE);
    Clk_Enable(ClkLSXT, TRUE);
    Clk_SetSource(ClkHSXT);
    
#ifdef DEBUG_PRINT    
    //config uart for debug
    Debug_UartInit();
    printf("debug start!\n");
#endif
    
    // Clear seconds interrupt flag
    u8IntSec = FALSE;

    // Time setting (23:59:00 1st of January 2014)
    stcTimeDate.u8Second = 00;                   // Second      : 00
    stcTimeDate.u8Minute = 59;                   // Minutes     : 59
    stcTimeDate.u8Hour   = 23;                   // Hour        : 23
    stcTimeDate.u8Day    = 30;                   // Date        : 30th
    stcTimeDate.u8Month  = RtcNovember;          // Month       : November
    stcTimeDate.u16Year   = 2014;                // Year        : 2014
    (void)Rtc_SetDayOfWeek(&stcTimeDate);        // Set Day of the Week in stcRtcTime

    // Alarm setting (00:00:00 1st of December 2014)
    stcAlarm.u8Minute = 0;              // Minutes : 00
    stcAlarm.u8Hour   = 0;              // Hour   : 00
    stcAlarm.u8Day    = 1;              // Date   : 1st
    stcAlarm.u8Month  = RtcDecember;    // Month  : December
    stcAlarm.u16Year   = 2014;          // Year   : 2014

    // Initilialize interrupts
    stcIrqEn.bHalfSecondIrq = 1u;
    stcIrqEn.bOneSecondIrq  = 1u;
    stcIrqEn.bAlarmIrq      = 1u;
    stcIrqCb.pfnHalfSecondIrqCb = SampleRtcHalfSencondCb;
    stcIrqCb.pfnOneSecondIrqCb  = SampleRtcOneSencondCb;
    stcIrqCb.pfnAlarmIrqCb      = SampleRtcAlarmCb;

    // Set time, alarm and interrupt structure pointer
    stcRtcConfig.enClkSel = RtcLSXTClk;
    stcRtcConfig.u32ClkPrescaler = RTC_CLOCK_PRES;

    stcRtcConfig.pstcTimeDate = &stcTimeDate;
    stcRtcConfig.pstcAlarm = &stcAlarm;
    stcRtcConfig.pstcIrqEn = &stcIrqEn;
    stcRtcConfig.pstcIrqCb = &stcIrqCb;

    stcRtcConfig.bRunNotInit = FALSE; // Don't initialize when RTC is running
    stcRtcConfig.bTouchNvic = TRUE;

    // Initialize the RTC
    enResult = Rtc_Init(&stcRtcConfig);

    if (Ok != enResult)
    {
#ifdef DEBUG_PRINT
        printf("Initial error!\n");
#endif
        while(1)
        {
            ;
        }
    }

    // Compare min,hour,day,month,year for Alarm
    EnableAlarm();

    // Start RTC counting
    Rtc_EnableFunc(RtcCount);

    while (1)
    {
        // If one second interruption occurs
        if (TRUE == u8IntSec)
        {
            u8IntSec = FALSE;
            Rtc_ReadDateTime(&stcTimeDate);
            #ifdef DEBUG_PRINT
                dumpTime(&stcTimeDate, DumpDateTime);
            #endif
        }

        if(u8AlarmOccur == 1)
        {
            u8AlarmOccur = 0;
        #ifdef DEBUG_PRINT
            printf("Alarm occurs!\n");
        #endif

            /* Set new time. */
            // Change time
            stcTimeDate.u8Second = 0;                    // Second      : 00
            stcTimeDate.u8Minute = 30;                   // Minutes     : 30
            stcTimeDate.u8Hour   = 9;                    // Hour        : 9

            Rtc_SetDateTime(&stcTimeDate, TRUE, TRUE, FALSE);

            /* Get the previous alarm time. */
            DDL_ZERO_STRUCT(stcAlarm);
            Rtc_GetAlarmDateTime(&stcAlarm);
            
            #ifdef DEBUG_PRINT
            printf("Previous alarm:");
            dumpTime(&stcAlarm, DumpAlarmTime);
            #endif

            /* Set the next alarm time. */
            DDL_ZERO_STRUCT(stcAlarm);
            stcAlarm.u8Second   = stcTimeDate.u8Second + 10;    // Second       : 10
            stcAlarm.u8Minute   = stcTimeDate.u8Minute;         // Minutes      : 30
            stcAlarm.u8Hour     = stcTimeDate.u8Hour;           // Hour         : 9
            
            Rtc_SetAlarmDateTime(&stcAlarm, TRUE, FALSE);
            EnableAlarm();

            /* Get the next previous alarm time. */
            DDL_ZERO_STRUCT(stcAlarm);
            Rtc_GetAlarmDateTime(&stcAlarm);
            
        #ifdef DEBUG_PRINT
            printf("Next alarm:");
            dumpTime(&stcAlarm, DumpAlarmTime);
        #endif

        #ifdef DEBUG_PRINT
            printf("New time is set\n");
        #endif
        }

        LedPolling();
    }
  
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/


