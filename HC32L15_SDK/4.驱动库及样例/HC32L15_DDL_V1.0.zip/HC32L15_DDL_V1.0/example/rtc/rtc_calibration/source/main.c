/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** This example demonstrates the calabration function of Real Time Clock. 
 **
 **   - 2016-11-1  1.0   First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "rtc.h"
#include "ct.h"
#include "gpio.h"
/******************************************************************************
 * Local pre-processor symbols/macros ('#define')                            
 ******************************************************************************/
#define RTC_CAL_TEST_VAL     RTC_MAX_FREQ_CORR_VALUE
#define RTC_CAL_CYCLE           1

/* PWC  */
#define  CT_PWC_CH             CtChannel0
#define  CT_PWC_TIMER_SIZE     PwcSize32Bit

#define  MEASURE_CNT_MAX         (10)      

#define RTC_CAL_FUNC_ON   1

/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')        
 ******************************************************************************/
uint32_t m_aMeasureResult[MEASURE_CNT_MAX];

/******************************************************************************
 * Local type definitions ('typedef')                                         
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void PwcOverflowIntHandler(void);
static void PwcMeasCmpIrqHandler(void);

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/
/** \brief Interrupt count value */
static volatile uint32_t m_u32CntIntMeasure;
static volatile uint32_t m_u32CntIntOverflow;

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')                             
 ******************************************************************************/


/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/


/**
 ******************************************************************************
 ** \brief PWC overflow interrupt handler
 ******************************************************************************
 */
static void PwcOverflowIntHandler(void)
{
    /*<<< user code here  */
    m_u32CntIntOverflow++;
}

/**
 ******************************************************************************
 ** \brief PWC measure complete interrupt handler
 ******************************************************************************
 */
static void PwcMeasCmpIrqHandler(void)
{
    uint32_t u32CntIntOverflow;
    
    /*<<< user code here  */
    if (m_u32CntIntMeasure < MEASURE_CNT_MAX)
    {  
        if (CT_PWC_TIMER_SIZE == PwcSize16Bit) 
        {
            u32CntIntOverflow = (m_u32CntIntOverflow * 0xffff);
            m_aMeasureResult[m_u32CntIntMeasure] = Ct_Pwc_Get16BitMeasureData(CT_PWC_CH) + u32CntIntOverflow;
        }
        else /*CT_32IT_TIMER  */
        {
            m_aMeasureResult[m_u32CntIntMeasure] = Ct_Pwc_Get32BitMeasureData(CT_PWC_CH);
        }             
        m_u32CntIntMeasure++;
    } 
    else
    {
        if (CT_PWC_TIMER_SIZE == PwcSize16Bit) 
        {
            Ct_Pwc_Get16BitMeasureData(CT_PWC_CH);
        }
        else
        {
            Ct_Pwc_Get32BitMeasureData(CT_PWC_CH);
        }
    }
    m_u32CntIntOverflow = 0;
}


/**
 ******************************************************************************
 ** \brief  Initialize RTC
 ******************************************************************************/
static void InitRtc(void)
{
    en_result_t enResult;
    stc_rtc_config_t stcRtcConfig;
    stc_rtc_freq_corr_t stcFreqCorrConfig;
    stc_rtc_time_t stcTimeDate;
    
    // Clear structures
    DDL_ZERO_STRUCT(stcRtcConfig);
    DDL_ZERO_STRUCT(stcFreqCorrConfig);
    DDL_ZERO_STRUCT(stcTimeDate);
    
    // Initialize RTCCO
    Gpio_SetFunc_RTCO_1(x);   //P34 JP65/47
    stcRtcConfig.enRtccoSel = RtccoOutput2Hz;

    // Initialize SUBOUT
    Gpio_SetFunc_SUBOUT_0(x);  //P45 JP65/49
    stcRtcConfig.bEnSuboutDivider = TRUE;
    stcRtcConfig.enDividerRatio = RtcDivRatio512;
    // Time setting (23:59:00 31st of December 2014)
    stcTimeDate.u8Second = 0;                    // Second      : 00
    stcTimeDate.u8Minute = 59;                   // Minutes     : 59
    stcTimeDate.u8Hour   = 23;                   // Hour        : 23
    stcTimeDate.u8Day    = 30;                   // Date        : 30th
    stcTimeDate.u8Month  = RtcDecember;          // Month       : December
    stcTimeDate.u16Year   = 2014;                // Year        : 2014
    (void)Rtc_SetDayOfWeek(&stcTimeDate);        // Set Day of the Week in stcRtcTime

    //set clock source and frequency
    stcRtcConfig.enClkSel = RtcLSXTClk;;
    stcRtcConfig.u32ClkPrescaler = RTC_CLOCK_PRES;

    // Set frequency correction, time pointer
    stcRtcConfig.pstcFreqCorrConfig = &stcFreqCorrConfig;
    stcRtcConfig.pstcTimeDate = &stcTimeDate;


    // Initialize the RTC
    enResult = Rtc_Init(&stcRtcConfig);

    if (Ok != enResult)
    {
#ifdef DEBUG_PRINT
        printf("Initial error!\n");
#endif
        while(1)
        {
            ;
        }
    }

    // Start RTC counting
    Rtc_EnableFunc(RtcCount);
}

#ifdef RTC_CAL_FUNC_ON
static void  SetRtcCorrFreq(void)
{
    /* Make sure the RIN_CLK is sub clock in InitRtc. */
    
    stc_rtc_freq_corr_t stcFreqCorrConfig;
    stcFreqCorrConfig.u16FreqCorrCycle = RTC_CAL_CYCLE;
    stcFreqCorrConfig.u16FreqCorrValue = RTC_CAL_TEST_VAL;
    
    Rtc_SetFreqCorrCfg(&stcFreqCorrConfig);
    Rtc_EnableFunc(RtcFreqCorr);
}
#endif
/**
 ******************************************************************************
 ** \brief  Initialize pwc function, this function can get the period of RTCCO
 ******************************************************************************/
static void pwc_measure(void)
{
    uint32_t u32Cnt;
//    uint32_t u32CntIntOverflow;
    stc_ct_pwc_config_t stcPwcConfig;
    stc_pwc_irq_en_t stcPwcIrqEn;
    stc_pwc_irq_cb_t stcPwcIrqCallback;
  
    /* Set IO port   */
    /* P15/INT13_2/SEG4/SOT6_1/TIOB0_0 */
    Gpio_SetFunc_TIOB0_0(0u);

    /* PWC register initialization   */
    stcPwcConfig.enPres = PwcPresNone;
    stcPwcConfig.enMode = PwcContinuous;
    stcPwcConfig.enMeasureEdge = PwcMeasureRisingToRising;
    stcPwcConfig.enSize = CT_PWC_TIMER_SIZE;
    stcPwcConfig.bTouchNvic =  TRUE;
    /* Initialize Pointer to interrupt request structure  */
    stcPwcConfig.pstcPwcIrqEn = &stcPwcIrqEn;
    stcPwcConfig.pstcPwcIrqCb = &stcPwcIrqCallback;
    /* Enable Interrupt   */
    stcPwcConfig.pstcPwcIrqEn->bPwcMeasureCompleteIrq = TRUE;
    stcPwcConfig.pstcPwcIrqEn->bPwcMeasureOverflowIrq = TRUE;
    stcPwcConfig.pstcPwcIrqCb->pfnPwcMeasureCompleteIrqCb = PwcMeasCmpIrqHandler;
    stcPwcConfig.pstcPwcIrqCb->pfnPwcMeasureOverflowIrqCb = PwcOverflowIntHandler;
    Ct_Pwc_Init(CT_PWC_CH, &stcPwcConfig);
    
    /* Enable count operatoin   */
    Ct_Pwc_EnableCount(CT_PWC_CH);

    /* Waiting for mesaurment compeleted  */
    while(m_u32CntIntMeasure < MEASURE_CNT_MAX)
    {
        ;
    }
    
    /* Disable Pwc count  */
    Ct_Pwc_DisableCount(CT_PWC_CH); 

    m_u32CntIntMeasure = 0;
    m_u32CntIntOverflow = 0;
    
    for(u32Cnt = 0; u32Cnt < MEASURE_CNT_MAX; u32Cnt++)
    {
        m_aMeasureResult[u32Cnt] = 0;
    } 

    /* Enable count operatoin   */
    Ct_Pwc_EnableCount(CT_PWC_CH);

#ifdef RTC_CAL_FUNC_ON
    SetRtcCorrFreq();
#endif

    /* Waiting for mesaurment compeleted  */
    while(m_u32CntIntMeasure < MEASURE_CNT_MAX)
    {
        ;
    }

    /* Disable Pwc count  */
    Ct_Pwc_DisableCount(CT_PWC_CH); /* Disable Pwc count  */
    
    Ct_Pwc_DeInit(CT_PWC_CH, TRUE); /* De-Initialize Pwc   */
}


/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_clk_config_t stcClkCfg;

    Rtc_DeInit(TRUE);
    
    DDL_ZERO_STRUCT(stcClkCfg);
    //config clock
    stcClkCfg.enBaseClkDiv = ClkBaseDiv1;
    stcClkCfg.enAPB1Div = ClkApb1Div1;
    stcClkCfg.enclkWaitMain = ClkCswtMain1ms;
    stcClkCfg.enAPB0Div = ClkApb0Div1;
    stcClkCfg.enclkWaitSub = ClkCswtSub256ms;
    Clk_Init(&stcClkCfg);
    Clk_Enable(ClkHSXT, TRUE);
    Clk_Enable(ClkLSXT, TRUE);
    Clk_SetSource(ClkHSXT);
    
#ifdef DEBUG_PRINT
    printf("***********************************************************\n");
    printf("*   RTC Calibration test                                  *\n");
    printf("*   Output 64KHz signal (before calibration) from SUBOUT_0  *\n");
    printf("*   Output 2Hz signal (after calibration) from RTCCO_1    *\n");
    printf("***********************************************************\n");
#endif
    
    // Configure RTC
    InitRtc();

    //config pwc function for test RTCCO
    pwc_measure();    
    
    while(1)
    {
        ;
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/


