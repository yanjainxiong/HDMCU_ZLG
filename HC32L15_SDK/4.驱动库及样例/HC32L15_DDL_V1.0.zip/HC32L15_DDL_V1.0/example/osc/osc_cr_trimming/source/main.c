/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** A detailed description is available at
 ** @link SampleGroup Some description @endlink
 **
 **   - 2016-10-16  1.0  HongJH First version for PWC mode sample of CT Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/

#include "ct.h"
#include "osc.h"
#include "math.h"
#include "stdlib.h"
#include "clk.h"
#include "gpio.h"
#include "flash.h"

/******************************************************************************/
/* Local pre-processor symbols/macros ('#define')                             */
/******************************************************************************/
/* PWC  */
#define  CT_PWC_CH             CtChannel0
#define  CT_PWC_TIMER_SIZE     PwcSize32Bit

#define  MEASURE_CNT_MAX       (9)

/*External OSC Freq. (Mhz) */
#define EXT_OSC_FREQ_MHZ        32
#define HCR_FREQ_INIT_VAL       0x100
#define HCR_TEMP_DEFAULT_VAL    0x08

/*Output HiCR Clock via ICRO_0 */
#define HICR_OUTPUT_DEBUG

/******************************************************************************/
/* Global variable definitions (declared in header file with 'extern')        */
/******************************************************************************/
uint32_t m_aMeasureResult[MEASURE_CNT_MAX];

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief State of high CR trim procedure
 **
 ** \note State of high CR trim procedure
 ******************************************************************************/
typedef enum en_TrimState {
    TRIM_PROC_INIT = 0,
    TRIM_PROC_START,
    TRIM_PROC_ONGOING_BIT7,
    TRIM_PROC_ONGOING_BIT6,
    TRIM_PROC_ONGOING_BIT5,
    TRIM_PROC_ONGOING_BIT4,
    TRIM_PROC_ONGOING_BIT3,
    TRIM_PROC_ONGOING_BIT2,
    TRIM_PROC_ONGOING_BIT1,
    TRIM_PROC_ONGOING_BIT0,
    TRIM_PROC_FINISH
}en_TrimState_t;

/**
 ******************************************************************************
 ** \brief Expected high CR trim frequnecy
 **
 ** \note 4MHz or 16MHz
 ******************************************************************************/
typedef enum en_Hicr_Freq {
    TrimHicr4MHz    = 4,
    TrimHicr16MHz   = 16
}en_Hicr_Freq_t;

/**
 ******************************************************************************
 ** \brief High CR trim value info. matrix
 **
 ** \note Record 9 times trim data
 ******************************************************************************/
typedef struct stc_Cr_Trim_Matrix {
    uint8_t u8Idx;
    uint16_t u16CrFreqTrimVal;
    uint32_t u32CalAbs;
}stc_Cr_Trim_Matrix_t;

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void PwcOverflowIntHandler(void);
static void PwcMeasCmpIrqHandler(void);

/******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
/** \brief Interrupt count value */
static volatile uint32_t m_u32CntIntMeasure;
static volatile uint32_t m_u32CntIntOverflow;
static volatile uint32_t m_u32CntMeasureErr;

/******************************************************************************/
/* Function implementation - global ('extern') and local ('static')           */
/******************************************************************************/

/******************************************************************************/
/* Local Functions                                                            */
/******************************************************************************/

/**
 ******************************************************************************
 ** \brief PWC overflow interrupt handler
 ******************************************************************************
 */
static void PwcOverflowIntHandler(void)
{
    /*<<< user code here  */
    m_u32CntIntOverflow++;
}

/**
 ******************************************************************************
 ** \brief PWC measure complete interrupt handler
 ******************************************************************************
 */
static void PwcMeasCmpIrqHandler(void)
{
    uint32_t u32CntIntOverflow;
    Ct_Pwc_DisableCount(CT_PWC_CH);
    /*<<< user code here  */
    if (m_u32CntIntMeasure < MEASURE_CNT_MAX)
    {
        if (CT_PWC_TIMER_SIZE == PwcSize16Bit)
        {
            u32CntIntOverflow = (m_u32CntIntOverflow * 0xffff);
            m_aMeasureResult[m_u32CntIntMeasure] = Ct_Pwc_Get16BitMeasureData(CT_PWC_CH) + u32CntIntOverflow;
        }
        else /*CT_32IT_TIMER  */
        {
            m_aMeasureResult[m_u32CntIntMeasure] = Ct_Pwc_Get32BitMeasureData(CT_PWC_CH);
        }
        m_u32CntIntMeasure++;
    }
    else
    {
        if (CT_PWC_TIMER_SIZE == PwcSize16Bit)
        {
            Ct_Pwc_Get16BitMeasureData(CT_PWC_CH);
        }
        else
        {
            Ct_Pwc_Get32BitMeasureData(CT_PWC_CH);
        }
    }
    m_u32CntIntOverflow = 0;
}

/*!
 ******************************************************************************
 ** \brief  High CR trimming process
 **
 ** \param  [in] u8TrimCrFreq            Expected trimming CR frequncey, MHz
 ** \param  [in] u8CrTempTrimDefaultVal  Temperature trim data, default value: 0x08
 ** \param  [out] u16pCrFreqTrimVal      Pointer to final trimming data
 **
 ** \retval Ok
 ** \retval Error
 ******************************************************************************
 *
 */
static uint8_t Osc_CrTrimProcess(en_Hicr_Freq_t u8TrimCrFreq,
                              uint8_t u8CrTempTrimDefaultVal,
                              uint16_t *u16pCrFreqTrimVal)
{
    static en_TrimState_t enTrimState = TRIM_PROC_INIT;
    stc_ct_pwc_config_t stcPwcConfig;
    stc_pwc_irq_en_t stcPwcIrqEn;
    stc_pwc_irq_cb_t stcPwcIrqCallback;

    uint8_t u8Count = 0;
    uint8_t u8TmpIdx;
    uint32_t u32TmpAbs;
    uint16_t u16CrFreqTrimInitValue = HCR_FREQ_INIT_VAL;
    uint32_t u32ExpPwcVal = 0;
    stc_Cr_Trim_Matrix_t a_stcCrTrimMatrix[9];
    a_stcCrTrimMatrix[0].u8Idx = 0;
    a_stcCrTrimMatrix[0].u16CrFreqTrimVal = u16CrFreqTrimInitValue;
    while(1)
    {
        switch (enTrimState)
        {
            case TRIM_PROC_INIT:
                Hicr_SetFreqDiv(HicrFreqDivBy512);  /* Divide HCR */
                M0P_GPIO->FN_SEL02_f.TIOB0S = 7u;   /* HCR output to CT ch.0 */

                Ct_ConfigIOMode(CT_PWC_CH, CtIoMode0);

                /* Clear structures  */
                ddl_memclr((uint8_t *)&stcPwcConfig, (uint32_t)(sizeof(stcPwcConfig)));
                ddl_memclr((uint8_t *)&stcPwcIrqEn, (uint32_t)(sizeof(stcPwcIrqEn)));
                ddl_memclr((uint8_t *)&stcPwcIrqCallback, (uint32_t)(sizeof(stcPwcIrqCallback)));

                /* PWC register initialization   */
                stcPwcConfig.enPres = PwcPresNone;
                stcPwcConfig.enMode = PwcContinuous;
                stcPwcConfig.enMeasureEdge = PwcMeasureRisingToRising;
                stcPwcConfig.enSize = CT_PWC_TIMER_SIZE;
                stcPwcConfig.bTouchNvic =  TRUE;

                /* enable PWC interrupt */
                stcPwcIrqEn.bPwcMeasureCompleteIrq = TRUE;
                stcPwcIrqEn.bPwcMeasureOverflowIrq = TRUE;
                stcPwcIrqCallback.pfnPwcMeasureCompleteIrqCb = PwcMeasCmpIrqHandler;
                stcPwcIrqCallback.pfnPwcMeasureOverflowIrqCb = PwcOverflowIntHandler;

                /* Initialize Pointer to interrupt request structure  */
                stcPwcConfig.pstcPwcIrqEn = &stcPwcIrqEn;
                stcPwcConfig.pstcPwcIrqCb = &stcPwcIrqCallback;

                /* PWC initalize */
                Ct_Pwc_Init(CT_PWC_CH, &stcPwcConfig);
                enTrimState++;
            break;
            case TRIM_PROC_START:
                if(TrimHicr4MHz == u8TrimCrFreq)
                {
                    /* Use 2MHz HCR */
                    Hicr_SetHicrFreq(Hicr2M);
                    /* Set default CR temperature trimming value */
                    Hicr_Set4MTempTrimmingData(u8CrTempTrimDefaultVal);
                    /* Set Initial CR freq. trimming value */
                    Hicr_Set4MFreqTrimmingData(u16CrFreqTrimInitValue);
                }
                else if(TrimHicr16MHz == u8TrimCrFreq)
                {
                    /* Use 8MHz HCR */
                    Hicr_SetHicrFreq(Hicr8M);
                    /* Set default CR temperature trimming value */
                    Hicr_Set16MTempTrimmingData(u8CrTempTrimDefaultVal);
                    /* Set Initial CR freq. trimming value */
                    Hicr_Set16MFreqTrimmingData(u16CrFreqTrimInitValue);
                }else{
                    ;
                }

                u32ExpPwcVal = EXT_OSC_FREQ_MHZ*2*(2<<(Hicr_GetFreqDiv()+1))/u8TrimCrFreq;
                delay1ms(1000);
                /* Enable count operatoin   */
                Ct_Pwc_EnableCount(CT_PWC_CH);
                delay1ms(1000);
                enTrimState++;
            break;
            case TRIM_PROC_ONGOING_BIT7:
            case TRIM_PROC_ONGOING_BIT6:
            case TRIM_PROC_ONGOING_BIT5:
            case TRIM_PROC_ONGOING_BIT4:
            case TRIM_PROC_ONGOING_BIT3:
            case TRIM_PROC_ONGOING_BIT2:
            case TRIM_PROC_ONGOING_BIT1:
            case TRIM_PROC_ONGOING_BIT0:
                if(m_aMeasureResult[u8Count] < u32ExpPwcVal)  /* CR freq. < the expected value */
                {
                    u16CrFreqTrimInitValue |= 1u<<(7-u8Count);
                }
                else if(m_aMeasureResult[u8Count] > u32ExpPwcVal)   /* CR freq. > the expected value */
                {
                    u16CrFreqTrimInitValue &= ~(1u<<(8-u8Count));
                    u16CrFreqTrimInitValue |= 1u<<(7-u8Count);
                }
                else
                {
                    __ASM("nop");
                }
                /* Record current value */
                a_stcCrTrimMatrix[u8Count+1].u8Idx = u8Count+1;
                a_stcCrTrimMatrix[u8Count+1].u16CrFreqTrimVal = u16CrFreqTrimInitValue;
                /* Calculate ABS of last time */
                a_stcCrTrimMatrix[u8Count].u32CalAbs = abs(u32ExpPwcVal - m_aMeasureResult[u8Count]);
                /* Set trim register */
                if(TrimHicr4MHz == u8TrimCrFreq)
                {
                    Hicr_Set4MFreqTrimmingData(u16CrFreqTrimInitValue);
                }
                else if(TrimHicr16MHz == u8TrimCrFreq)
                {
                    Hicr_Set16MFreqTrimmingData(u16CrFreqTrimInitValue);
                }else
                {
                    ;
                }


                /* Enable count operatoin   */
                Ct_Pwc_EnableCount(CT_PWC_CH);
                delay1ms(1000);
                u8Count++;
                enTrimState++;
                break;
            case TRIM_PROC_FINISH:
                break;
            default:
                break;
        }
        if (TRIM_PROC_FINISH == enTrimState)
        {
            a_stcCrTrimMatrix[u8Count].u32CalAbs = abs(u32ExpPwcVal - m_aMeasureResult[u8Count]);
            u32TmpAbs = a_stcCrTrimMatrix[0].u32CalAbs;
            for(u8Count = 0; u8Count < 8; u8Count++)
            {
                if(a_stcCrTrimMatrix[u8Count].u32CalAbs < u32TmpAbs)
                {
                    u32TmpAbs = a_stcCrTrimMatrix[u8Count].u32CalAbs;
                    u8TmpIdx = a_stcCrTrimMatrix[u8Count].u8Idx;
                }
            }
            *u16pCrFreqTrimVal = a_stcCrTrimMatrix[u8TmpIdx].u16CrFreqTrimVal;
            return Ok;
        }
    }
}

/******************************************************************************/
/* Global Functions                                                           */
/******************************************************************************/

/**
 ******************************************************************************
 ** \brief  Main function of HiCR trim sample for HC32L15 series.
 **
 ** \param  none
 ** \return uint32_t return value, if needed
 ******************************************************************************/
int32_t main(void)
{
    uint16_t u32FreqTrimVal;

    uint8_t u8CrTempTrimDefaultVal = HCR_TEMP_DEFAULT_VAL;
    en_Hicr_Freq_t enHicrFreqTrim = TrimHicr16MHz;
    uint32_t u32Udr0, u32Udr1, u32Udr2 = 0, u32Udr3 = 0;

    m_u32CntIntMeasure = 0;
    m_u32CntIntOverflow =0;
    m_u32CntMeasureErr = 0;
    Gpio_SetFunc_IRCO_0(0);
    Clk_DisableFunc(ClkFuncHSXTReset);
    Clk_DisableFunc(ClkFuncHSXT);
    Clk_SwitchTo(ClkHSXT);

    SystemCoreClock = Clk_GetSystemClk();

    Osc_CrTrimProcess(enHicrFreqTrim, u8CrTempTrimDefaultVal, &u32FreqTrimVal);

#ifdef HICR_OUTPUT_DEBUG
    /* write to NVR */
    Flash_PgmTimerConfig(3u);
    Flash_PageErase(0x100000u);
    Flash_UdrRead(FUDR0, &u32Udr0);
    Flash_WriteWord(0x100004, u32Udr0);
    Flash_UdrRead(FUDR1, &u32Udr1);
    Flash_WriteWord(0x100008, u32Udr1);
//    Flash_UdrRead(FUDR2, &u32Udr2);
//    Flash_WriteWord(0x10000C, u32Udr2);
//    Flash_UdrRead(FUDR3, &u32Udr3);
//    Flash_WriteWord(0x100010, u32Udr3);

    /* Resume previous setting */
    if(TrimHicr4MHz == enHicrFreqTrim)
    {
        Flash_UdrRead(FUDR2, &u32Udr2);
        Flash_WriteWord(0x10000Cu, u32Udr2);
        
        u32Udr3 |= (uint32_t)u32FreqTrimVal << 8u;
        u32Udr3 |= HCR_TEMP_DEFAULT_VAL;
        Flash_WriteWord(0x100010u, u32Udr3);
        Hicr_SetHicrFreq(Hicr4M);
    }
    else if(TrimHicr16MHz == enHicrFreqTrim)
    {
        Flash_UdrRead(FUDR2, &u32Udr3);
        Flash_WriteWord(0x100010u, u32Udr3);
        
        u32Udr2 |= (uint32_t)u32FreqTrimVal << 16u;
        u32Udr2 |= HCR_TEMP_DEFAULT_VAL << 8;
        Flash_WriteWord(0x10000Cu, u32Udr2);
        Hicr_SetHicrFreq(Hicr16M);
    }else
    {
        ;
    }

    /* Output Hicr freq. via IRCO_0 (P67) */
    Gpio_SetFunc_IRCO_0(0);
#endif
    while(1)
    {
        ;
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
