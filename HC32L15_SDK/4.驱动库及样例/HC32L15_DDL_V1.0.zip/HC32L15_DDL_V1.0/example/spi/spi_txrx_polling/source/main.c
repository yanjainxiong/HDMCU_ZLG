/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for spi tx and rx by polling demonstration.
 **
 **   - 2016-02-16  1.0  QCP First version for Device Driver Library of spi.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "spi.h"
#include "gpio.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define     SPI_TX_CH           (1)
#define     SPI_RX_CH           (4)

#define     BUFF_SZ             (20)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
char u8TxBuff[] = "1234567890abcdedf";
char u8RxBuff[BUFF_SZ];

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint8_t u8RxCnt = 0;

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief  Main function of project
 **
 ** \param [in]  None
 **
 ** \retval uint32_t return value, if needed
 **
 ** This sample use ch1 to send data and use ch4 to receive
 ** data.(use polling mode)
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_spi_config_t    stcConfigTx;
    stc_spi_config_t    stcConfigRx;
    uint32_t            u32offset = 0;

    ddl_memclr(&stcConfigTx,sizeof(stcConfigTx));
    ddl_memclr(&stcConfigRx,sizeof(stcConfigRx));

    stcConfigRx.bInvertClk = FALSE;
    stcConfigRx.bMSB = TRUE;
    stcConfigRx.bOutputData = TRUE;
    stcConfigRx.bOutputSCK = FALSE;
    stcConfigRx.bSOTHigh = FALSE;
    stcConfigRx.bSPIMode = TRUE;
    stcConfigRx.enDataLen = SpiDataLen8;
    stcConfigRx.bSlaveMode = TRUE;
    stcConfigRx.u32BaudRate = 100*1000;
    stcConfigRx.u8DataOuputDly = 3;


    Gpio_SetFunc_SCK1_0(x);
    Gpio_SetFunc_SOT1_0(x);
    Gpio_SetFunc_SCK4_0(x);
    Gpio_SetFunc_SIN4_0(x);

    Spi_Init(SPI_RX_CH,&stcConfigRx);

    ddl_memclr(&stcConfigTx,sizeof(stcConfigTx));

    stcConfigTx = stcConfigRx;
    stcConfigTx.bSlaveMode = FALSE;
    stcConfigTx.bOutputSCK = TRUE;

    Spi_Init(SPI_TX_CH,&stcConfigTx);

    Spi_EnableFunc(SPI_RX_CH,SpiFuncRx);

    Spi_EnableFunc(SPI_TX_CH,SpiFuncTx);

    while (u32offset < strlen(u8TxBuff))
    {
        //tx a byte
        while (FALSE == Spi_GetStatus(SPI_TX_CH,SpiTxEmpty))
        {
            ;
        }
        Spi_SendData(SPI_TX_CH,u8TxBuff[u32offset]);

        //rx a byte
        while (FALSE == Spi_GetStatus(SPI_RX_CH,SpiRxFull))
        {
            ;
        }
        u8RxBuff[u32offset] = Spi_ReceiveData(SPI_RX_CH,FALSE);
        u32offset++;
    }

    Spi_DeInit(SPI_TX_CH);
    Spi_DeInit(SPI_RX_CH);

    Debug_UartInit();

    while (1)
    {
        ;
    }

}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
