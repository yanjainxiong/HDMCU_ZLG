/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for PPG function demonstration
 **		   Get more details from readme text.
 **
 **   - 2016-10-16  1.0  HongJH First version for PPG mode sample of CT Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "clk.h"
#include "ct.h"
#include "gpio.h"


/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define  CT_CH          CtChannel0
#define  CT_PPG_MODE    PpgContinuous

#define  LOW_WIDTH      (499u)
/************** HCR **************/
//    125us if Master Clock =  4MHz; HCLK = Master Clock / 1 =  4MHz;  PCLK0 = HCLK / 1 =   4MHz;
//  31.25us if Master Clock = 16MHz; HCLK = Master Clock / 1 = 16MHz;  PCLK0 = HCLK / 1 = 16MHz;
/************ Ext HCR ************/
// 62.500us if Master Clock =  8MHz; HCLK = Master Clock / 1 =  8MHz;  PCLK0 = HCLK / 1 =  8MHz;
// 20.833us if Master Clock = 24MHz; HCLK = Master Clock / 1 = 24MHz;  PCLK0 = HCLK / 1 = 24MHz;
// 15.625us if Master Clock = 32MHz; HCLK = Master Clock / 1 = 32MHz;  PCLK0 = HCLK / 1 = 32MHz;
/************** LCR **************/
// 15.625ms if Master Clock = 32000Hz; HCLK = Master Clock / 1 = 32000Hz;  PCLK0 = HCLK / 1 = 32000Hz;
/************ Ext LCR ************/
// 15.259ms if Master Clock = 32768Hz; HCLK = Master Clock / 1 = 32768Hz;  PCLK0 = HCLK / 1 = 32768Hz;

#define  HIGH_WIDTH     (499u)
/************** HCR **************/
//    125us if Master Clock =  4MHz; HCLK = Master Clock / 1 =  4MHz;  PCLK0 = HCLK / 1 =  4MHz;
//  31.25us if Master Clock = 16MHz; HCLK = Master Clock / 1 = 16MHz;  PCLK0 = HCLK / 1 = 16MHz;
/************ Ext HCR ************/
// 62.500us if Master Clock =  8MHz; HCLK = Master Clock / 1 =  8MHz;  PCLK0 = HCLK / 1 =  8MHz;
// 20.833us if Master Clock = 24MHz; HCLK = Master Clock / 1 = 24MHz;  PCLK0 = HCLK / 1 = 24MHz;
// 15.625us if Master Clock = 32MHz; HCLK = Master Clock / 1 = 32MHz;  PCLK0 = HCLK / 1 = 32MHz;
/************** LCR **************/
// 15.625ms if Master Clock = 32000Hz; HCLK = Master Clock / 1 = 32000Hz;  PCLK0 = HCLK / 1 = 32000Hz;
/************ Ext LCR ************/
// 15.259ms if Master Clock = 32768Hz; HCLK = Master Clock / 1 = 32768Hz;  PCLK0 = HCLK / 1 = 32768Hz;


/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void PpgTrigIrqHandler(void);
static void PpgUnderflowIrqHandler(void);

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint32_t m_u32CntIntTrg = 0;
static volatile uint32_t m_u32CntIntUnder = 0;

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local Functions
 ******************************************************************************/

/**
 *******************************************************************************
 ** \brief PPG trigger interrupt handler
 *******************************************************************************
 */
static void PpgTrigIrqHandler(void)
{
    m_u32CntIntTrg++;
}

/**
 *******************************************************************************
 ** \brief PPG underflow interrupt handler
 *******************************************************************************
 */
static void PpgUnderflowIrqHandler(void)
{
    m_u32CntIntUnder++;
}

/*******************************************************************************
 * Global Functions
 ******************************************************************************/

/**
 *******************************************************************************
 ** \brief  Main function of ct-ppg sample for HC32l15 series.
 **
 ** \param  none
 ** \return uint32_t return value, if needed
 ******************************************************************************/
int32_t main(void)
{
    stc_ppg_irq_en_t    stcIrqEn;
    stc_ppg_irq_cb_t    stcIrqCb;
    stc_ct_ppg_config_t stcPpgConfig;

    /* Set System clock   */
    Clk_SwitchTo(ClkHICR);

    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPpgConfig, (uint32_t)(sizeof(stcPpgConfig)));
    ddl_memclr((uint8_t *)&stcIrqEn, (uint32_t)(sizeof(stcIrqEn)));
    ddl_memclr((uint8_t *)&stcIrqCb, (uint32_t)(sizeof(stcIrqCb)));

    /* Set Composite Timer  IO port   */
    /* P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0 */
    Gpio_SetFunc_TIOA0_0(0u);

    /* Set Composite Timer  I/O mode   */
    Ct_ConfigIOMode(CT_CH, CtIoMode0);

    /* Initialize Pointer to interrupt request structure  */
    stcPpgConfig.pstcPpgIrqEn = &stcIrqEn;
    stcPpgConfig.pstcPpgIrqCb = &stcIrqCb;
    /* Initialize PPG timer  */
    stcPpgConfig.enPres = PpgPresNone;
    stcPpgConfig.enMode = CT_PPG_MODE;
    stcPpgConfig.enExtTrig = PpgExtTrigDisable;
    stcPpgConfig.enOutputMask = PpgOutputNormal;
    stcPpgConfig.enOutputPolarity = PpgPolarityLow;
    stcPpgConfig.enRestartEn = PpgRestartEnable;
    stcPpgConfig.pstcPpgIrqEn->bPpgTrigIrq = TRUE;
    stcPpgConfig.pstcPpgIrqEn->bPpgUnderflowIrq = TRUE;
    stcPpgConfig.pstcPpgIrqCb->pfnPpgTrigIrqCb = PpgTrigIrqHandler;
    stcPpgConfig.pstcPpgIrqCb->pfnPpgUnderflowIrqCb = PpgUnderflowIrqHandler;
    stcPpgConfig.bTouchNvic = TRUE;
    Ct_Ppg_Init(CT_CH, &stcPpgConfig);

    /* Set cycle and duty value  */
    Ct_Ppg_WriteLowWidthVal(CT_CH, LOW_WIDTH);   /* Cycle = (1+m)*PPG clock cycle  */
    Ct_Ppg_WriteHighWidthVal(CT_CH, HIGH_WIDTH); /* Duty = (1+m)*PPG clock cycle   */

    Ct_Ppg_EnableCount(CT_CH);  /* Enable count operatoin  */
    Ct_Ppg_EnableSwTrig(CT_CH); /* Start triggered by software  */

    while(m_u32CntIntUnder < 2500UL)
    {
        ;
    }

    /* Disable Interrupt   */
    Ct_Ppg_DisableIrq(CT_CH, PpgTrigIrq);
    Ct_Ppg_DisableIrq(CT_CH, PpgUnderflowIrq);
    /* Disable PPG count  */
    Ct_Ppg_DisableCount(CT_CH);

    m_u32CntIntTrg = 0;
    m_u32CntIntUnder = 0;

    Ct_Ppg_EnableCount(CT_CH);  /* Enable count operatoin  */
    Ct_Ppg_EnableSwTrig(CT_CH); /* Start triggered by software  */

    /* Interrupt query mode   */
    do
    {
        if (Ct_Ppg_GetIrqFlag(CT_CH, PpgTrigIrq) == TRUE)
        {
            Ct_Ppg_ClrIrqFlag(CT_CH, PpgTrigIrq);
            m_u32CntIntTrg++;
        }
        else if (Ct_Ppg_GetIrqFlag(CT_CH, PpgUnderflowIrq) == TRUE)
        {
            Ct_Ppg_ClrIrqFlag(CT_CH, PpgUnderflowIrq);
            m_u32CntIntUnder++;
        }else{
            ;
        }
    } while(m_u32CntIntUnder < 2500UL);

    Ct_Ppg_DisableCount(CT_CH); /* Disable PPG count  */
    Ct_Ppg_DeInit(CT_CH, TRUE); /* De-Initialize PPG   */

    while(1)
    {
        ;
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/

