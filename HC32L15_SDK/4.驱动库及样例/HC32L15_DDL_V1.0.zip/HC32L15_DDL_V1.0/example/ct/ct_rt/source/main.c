/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for RT function demonstration
 **        Get more details from readme text.
 **
 **   - 2016-10-16  1.0  HongJH First version for RT mode sample of CT Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "clk.h"
#include "ct.h"
#include "gpio.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define  CT_CH           CtChannel0
#define  CT_RT_MODE      RtReload
#define  CT_TIMER_SIZE   RtSize32Bit

#define  CT_RT_CYCLE     (999u)
/**************HCR**************/
//    250us if Master Clock =  4MHz; HCLK = Master Clock / 1 =  4MHz;  PCLK0 = HCLK / 1 =  4MHz;
//  62.05us if Master Clock = 16MHz; HCLK = Master Clock / 1 = 16MHz;  PCLK0 = HCLK / 1 = 16MHz;
/************Ext HCR************/
//    125us if Master Clock =  8MHz; HCLK = Master Clock / 1 =  8MHz;  PCLK0 = HCLK / 1 =  8MHz;
// 41.667us if Master Clock = 24MHz; HCLK = Master Clock / 1 = 24MHz;  PCLK0 = HCLK / 1 = 24MHz;
// 31.250us if Master Clock = 32MHz; HCLK = Master Clock / 1 = 32MHz;  PCLK0 = HCLK / 1 = 32MHz;
/**************LCR**************/
// 31.250ms if Master Clock = 32000Hz; HCLK = Master Clock / 1 = 32000Hz;  PCLK0 = HCLK / 1 = 32000Hz;
/************Ext LCR************/
// 30.518ms if Master Clock = 32768Hz; HCLK = Master Clock / 1 = 32768Hz;  PCLK0 = HCLK / 1 = 32768Hz;

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
static void RtTrigIrqHandler(void);
static void RtUnderflowIrqHandler(void);

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
/** \brief Interrupt count value */
static volatile uint32_t m_u32CntIrqTrg = 0u;
static volatile uint32_t m_u32CntIrqUnder = 0u;

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local Functions
 ******************************************************************************/

/**
 *******************************************************************************
 ** \brief RT trigger interrupt handler
 *******************************************************************************
 */
static void RtTrigIrqHandler(void)
{
    m_u32CntIrqTrg++;
}

/**
 ******************************************************************************
 ** \brief RT underflow interrupt handler
 ******************************************************************************
 */
static void RtUnderflowIrqHandler(void)
{
    m_u32CntIrqUnder++;
}

/******************************************************************************/
/* Global Functions                                                           */
/******************************************************************************/

/**
 ******************************************************************************
 ** \brief  Main function of ct-rt sample for HC32L15 series.
 **
 ** \param  none
 ** \retval uint32_t return value, if needed
 ******************************************************************************/
int32_t main(void)
{
    stc_rt_irq_en_t    stcIrqEn;
    stc_rt_irq_cb_t    stcIrqCb;
    stc_ct_rt_config_t stcRtConfig;

    /* Set System clock   */
    Clk_SwitchTo(ClkHICR);

    /* Clear structures */
    ddl_memclr((uint8_t*)&stcIrqEn, (uint32_t)(sizeof(stcIrqEn)));
    ddl_memclr((uint8_t*)&stcIrqCb, (uint32_t)(sizeof(stcIrqCb)));
    ddl_memclr((uint8_t*)&stcRtConfig, (uint32_t)(sizeof(stcRtConfig)));

    /* Set Composite Timer  IO mode  */
    Ct_ConfigIOMode(CT_CH, CtIoMode0);

    /* Set Composite Timer  IO port  */
    /* P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0 */
    Gpio_SetFunc_TIOA0_0(0u);

    /* Initialize Pointer to interrupt request structure  */
    stcRtConfig.pstcRtIrqEn = &stcIrqEn;
    stcRtConfig.pstcRtIrqCb = &stcIrqCb;
    /* Initialize Composite Timer  */
    stcRtConfig.enPres = RtPresNone;
    stcRtConfig.enSize = CT_TIMER_SIZE;
    stcRtConfig.enMode = CT_RT_MODE;
    stcRtConfig.enExtTrig = RtExtTiggerDisable;
    stcRtConfig.enOutputPolarity = RtPolarityLow;
    stcRtConfig.pstcRtIrqEn->bRtTrigIrq = 1;
    stcRtConfig.pstcRtIrqEn->bRtUnderflowIrq = 1;
    stcRtConfig.pstcRtIrqCb->pfnRtTrigIrqCb = RtTrigIrqHandler ;
    stcRtConfig.pstcRtIrqCb->pfnRtUnderflowIrqCb = RtUnderflowIrqHandler;
    stcRtConfig.bTouchNvic = TRUE;
    Ct_Rt_Init(CT_CH, &stcRtConfig);

    /* Write cycle value */
    Ct_Rt_WriteCycleVal(CT_CH, CT_RT_CYCLE);  /* Cycle = T*(m+1)  */
    /* Start Reload timer by software trigger  */
    Ct_Rt_EnableCount(CT_CH);
    Ct_Rt_EnableSwTrig(CT_CH);

    while(m_u32CntIrqUnder < 2500ul)
    {
        ;
    }

    /* Disable Interrupt */
    Ct_Rt_DisableIrq(CT_CH, RtTrigIrq);
    Ct_Rt_DisableIrq(CT_CH, RtUnderflowIrq);
    /* Disable RT count  */
    Ct_Rt_DisableCount(CT_CH);

    m_u32CntIrqTrg = 0;
    m_u32CntIrqUnder = 0;

    Ct_Rt_EnableCount(CT_CH);  /* Disable RT count  */
    Ct_Rt_EnableSwTrig(CT_CH); /* Restart triggered by software */

    /* Interrupt query mode */
    do
    {
        if (1u == Ct_Rt_GetIrqFlag(CT_CH, RtTrigIrq))
        {
            Ct_Rt_ClrIrqFlag(CT_CH, RtTrigIrq);
            m_u32CntIrqTrg++;
        }
        else if (1u == Ct_Rt_GetIrqFlag(CT_CH, RtUnderflowIrq))
        {
            Ct_Rt_ClrIrqFlag(CT_CH, RtUnderflowIrq);
            m_u32CntIrqUnder++;
        }else{
            ;
        }
    } while(m_u32CntIrqUnder < 2500ul);

    Ct_Rt_DisableCount(CT_CH); /* Disable RT count  */
    Ct_Rt_DeInit(CT_CH, TRUE); /* De-Initialize RT   */

    while(1)
    {
        ;
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/

