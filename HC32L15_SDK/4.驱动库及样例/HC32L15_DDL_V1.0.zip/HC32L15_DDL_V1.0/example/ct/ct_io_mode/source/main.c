/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for io mode demonstration
 **        Get more details from readme text.
 **
 **   - 2016-10-16  1.0  HongJH First version for I/O mode sample of CT Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "clk.h"
#include "ct.h"
#include "gpio.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/** \brief Demo CT IO mode 0 */
#define  DEMO_CT_IOMODE_0               0
/** \brief Demo CT IO mode 1 */
#define  DEMO_CT_IOMODE_1               1
/** \brief Demo CT IO mode 2,3  */
#define  DEMO_CT_IOMODE_2_3             2
/** \brief Demo CT IO mode 2,8  */
#define  DEMO_CT_IOMODE_2_8             3
/** \brief Demo CT IO mode 4  */
#define  DEMO_CT_IOMODE_4               4
/** \brief Demo CT IO mode 5  */
#define  DEMO_CT_IOMODE_5               5
/** \brief Demo CT IO mode 6  */
#define  DEMO_CT_IOMODE_6               6
/** \brief Demo CT IO mode 7  */
#define  DEMO_CT_IOMODE_7               7

/** \brief Select a demo mode  */
#define  DEMO_MODE                      DEMO_CT_IOMODE_0

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local Functions
 ******************************************************************************/

/**
 *******************************************************************************
 ** \brief This configure Composite timer I/O
 **
 ** \param [in]   none
 ** \param [out]  none
 **
 *******************************************************************************
 */
#if (DEMO_MODE == DEMO_CT_IOMODE_0)
/**
 *******************************************************************************
 ** \brief CT IO mode 1 demo code
 *******************************************************************************
 */
static void DemoCtIoMode0(void)
{
    stc_ct_pwm_config_t stcPwmConfig;
    /* Set Composite Timer IO port  */
    Gpio_SetFunc_TIOA0_0(x); /*TIOA0_0_OUT:   P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0*/
    Gpio_SetFunc_TIOB0_0(x);  /*TIOB0_0_IN:    P15/INT13_2/SEG4/SOT6_1/TIOB0_0*/
    Gpio_SetFunc_TIOA1_0_OUT(x); /*TIOA1_0_OUT:   P16/INT14_2/SEG3/SCK6_1/TIOA1_0*/
    Gpio_SetFunc_TIOB1_0(x); /*TIOB1_0_IN:    P17/INT15_2/SEG2/SCS60_1/TIOB1_0*/

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode0);

    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigBoth;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartDisable;
    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 999); /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz  */
    Ct_Pwm_WriteDutyVal(CtChannel0, 199);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz  */
    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);

    //Ct_Pwm_EnableSwTrig(CtChannel0);/* Start triggered by software  */

    while(1)
    {
        ;
    }
}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_1)
/**
 *******************************************************************************
 ** \brief CT IO mode 1 demo code
 *******************************************************************************
 */
static void DemoCtIoMode1(void)
{
    volatile uint32_t i = 0;
    stc_rt_irq_en_t    stcIrqEn;
    stc_rt_irq_cb_t    stcIrqCb;
    stc_ct_rt_config_t stcRtConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();    /*TIOA0_0_OUT:   P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0*/
    Gpio_SetFunc_TIOB0_0();    /*TIOB0_0_IN:    P15/INT13_2/SEG4/SOT6_1/TIOB0_0*/
    Gpio_SetFunc_TIOA1_0_IN(); /*TIOA1_0_IN:    P16/INT14_2/SEG3/SCK6_1/TIOA1_0*/
    Gpio_SetFunc_TIOB1_0();    /*TIOB1_0_IN:    P17/INT15_2/SEG2/SCS60_1/TIOB1_0*/

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode1);

    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcRtConfig, (uint32_t)(sizeof(stcRtConfig)));
    ddl_memclr((uint8_t *)&stcIrqEn, (uint32_t)(sizeof(stcIrqEn)));
    ddl_memclr((uint8_t *)&stcIrqCb, (uint32_t)(sizeof(stcIrqCb)));

    /* Initialize interrupt  */
    stcRtConfig.pstcRtIrqEn = &stcIrqEn;
    stcRtConfig.pstcRtIrqCb = &stcIrqCb;
    /* Initialize RT timer  */
    stcRtConfig.enPres = RtPresNone;
    stcRtConfig.enMode = RtReload;
    stcRtConfig.enExtTrig = RtExtTiggerRisingEdge;
    stcRtConfig.enSize = RtSize32Bit;
    stcRtConfig.enOutputPolarity = RtPolarityLow;
    stcRtConfig.bTouchNvic = FALSE;
    Ct_Rt_Init(CtChannel0, &stcRtConfig);

    /* Set cycle and duty value  */
    Ct_Rt_WriteCycleVal(CtChannel0, 999);  /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    /* ����GPIO P50������͵�ƽ */
    /*P00/INT00_0/A0/AVref/SEG21/SIN5_0/SCK1_0/TIOA1_2  */
    Gpio_InitIO(0,0,GpioDirOut,FALSE,FALSE);

    /* Enable count operatoin  */
    Ct_Rt_EnableCount(CtChannel0);
    while(1)
    {
        for(i = 0; i < 100; i++);
        Gpio_SetIO(0,0,1);  /*output: high level */

        for(i = 0; i < 100; i++);
        Gpio_SetIO(0,0,0);  /*output: low level */
    }
}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_2_3)

/**
 *******************************************************************************
 ** \brief CT IO mode 2,3 demo code
 *******************************************************************************
 */
static void DemoCtIoMode23(void)
{
    stc_ct_pwm_config_t stcPwmConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();  /*TIOA0_0_OUT:   P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0*/
    Gpio_SetFunc_TIOB0_0();  /*TIOB0_0_IN:    P15/INT13_2/SEG4/SOT6_1/TIOB0_0*/
    Gpio_SetFunc_TIOA1_0_OUT();/*TIOA1_0_OUT:   P16/INT14_2/SEG3/SCK6_1/TIOA1_0*/
    //Gpio_SetFunc_TIOB1_0();  /*TIOB1_0_IN:    P17/INT15_2/SEG2/SCS60_1/TIOB1_0*/

    Gpio_SetFunc_TIOA2_0(); /*TIOA2_0_OUT:   P52/INT06_0/A10/SEG23/SCK0_1/SIN1_0/ICRST_0/TIOA2_0*/
    //Gpio_SetFunc_TIOB2_0(); /*TIOB2_0_IN:    P53/INT07_0/A11/SEG22/SOT1_0/TIOB2_0/BZ_0*/
    Gpio_SetFunc_TIOA3_0_OUT(); /*TIOA3_0_OUT:   P50/INT12_1/A8/SEG25/SIN0_1/CTS1_0/ICCK_0/TIOA3_0*/

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode2);
    Ct_ConfigIOMode(CtChannel2, CtIoMode3);

    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigRising;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartDisable;

    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel2, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel3, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 999); /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel0, 199);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */

    Ct_Pwm_WriteCycleVal(CtChannel1, 999); /* Cycle = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteDutyVal(CtChannel1, 199);  /* Duty = (1+m)*PWM clock cycle  */
    Ct_Pwm_WriteCycleVal(CtChannel2, 999); /* Cycle = (1+m)*PWM clock cycle  */
    Ct_Pwm_WriteDutyVal(CtChannel2, 199);  /* Duty = (1+m)*PWM clock cycle  */
    Ct_Pwm_WriteCycleVal(CtChannel3, 999); /* Cycle = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteDutyVal(CtChannel3, 199);  /* Duty = (1+m)*PWM clock cycle  */
    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);
    Ct_Pwm_EnableCount(CtChannel2);
    Ct_Pwm_EnableCount(CtChannel3);

    while(1);

}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_2_8)

/**
 *******************************************************************************
 ** \brief CT IO mode 2,3,8 demo code
 *******************************************************************************
 */
static void DemoCtIoMode28(void)
{
    volatile uint16_t i = 0;
    stc_ct_pwm_config_t stcPwmConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();    /*TIOA0_0_OUT:   P14/INT12_2/SEG5/SIN6_1/TIOB2_1/TIOA0_0*/
    Gpio_SetFunc_TIOB0_0();    /*TIOB0_0_IN:    P15/INT13_2/SEG4/SOT6_1/TIOB0_0*/
    Gpio_SetFunc_TIOA1_0_OUT();/*TIOA1_0_OUT:   P16/INT14_2/SEG3/SCK6_1/TIOA1_0*/
    //Gpio_SetFunc_TIOB1_0();      /*TIOB1_0_IN:    P17/INT15_2/SEG2/SCS60_1/TIOB1_0*/

    Gpio_SetFunc_TIOA2_0(); /*TIOA2_0_OUT:   P52/INT06_0/A10/SEG23/SCK0_1/SIN1_0/ICRST_0/TIOA2_0*/
    //Gpio_SetFunc_TIOB2_0(); /*TIOB2_0_IN:    P53/INT07_0/A11/SEG22/SOT1_0/TIOB2_0/BZ_0*/
    Gpio_SetFunc_TIOA3_0_OUT(); /*TIOA3_0_OUT:   P50/INT12_1/A8/SEG25/SIN0_1/CTS1_0/ICCK_0/TIOA3_0*/

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode2);
    Ct_ConfigIOMode(CtChannel2, CtIoMode8);

    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigRising;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartDisable;

    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel2, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel3, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 1999);/* Cycle = (1+m)*PWM clock cycle   */
                                     /* 500us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 250us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 250ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 244ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel0,  999); /* Duty = (1+m)*PWM clock cycle    */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteCycleVal(CtChannel1, 1999);/* Cycle = (1+m)*PWM clock cycle  */
    Ct_Pwm_WriteDutyVal(CtChannel1,  999); /* Duty = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteCycleVal(CtChannel2, 199); /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel2,  99);  /* Duty = (1+m)*PWM clock cycle   */
                                     /* 25us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 12.5us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 12.5ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 12.2ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteCycleVal(CtChannel3, 199); /* Cycle = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteDutyVal(CtChannel3,  99);  /* Duty = (1+m)*PWM clock cycle   */
    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);
    Ct_Pwm_EnableCount(CtChannel2);
    Ct_Pwm_EnableCount(CtChannel3);

    /*P00/INT00_0/A0/AVref/SEG21/SIN5_0/SCK1_0/TIOA1_2  */
    Gpio_InitIO(0,0,GpioDirOut,FALSE,FALSE);

    /* Enable count operatoin  */
    while(1)
    {
        for(i = 0; i < 100; i++);
        Gpio_SetIO(0,0,1);  /*output: high level */

        for(i = 0; i < 100; i++);
        Gpio_SetIO(0,0,0);  /*output: low level */
    }
}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_4)

/**
 *******************************************************************************
 ** \brief CT IO mode 4 demo code
 *******************************************************************************
 */
static void DemoCtIoMode4(void)
{
    stc_ct_pwm_config_t stcPwmConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();
    Gpio_SetFunc_TIOB0_0();
    Gpio_SetFunc_TIOA1_0_OUT();

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode4);
    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigRising;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartDisable;
    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 0x10); /* Cycle = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteDutyVal(CtChannel0,  0x09); /* Duty = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteCycleVal(CtChannel1, 0x02); /*  Cycle = (1+m)*PWM clock cycle  */
    Ct_Pwm_WriteDutyVal(CtChannel1,  0x01); /* Duty = (1+m)*PWM clock cycle   */

    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);

    /* Software trigger  */
    //Ct_Pwm_EnableSwTrig(CtChannel0);
    while(1);
}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_5)

/**
 *******************************************************************************
 ** \brief CT IO mode 5 demo code
 *******************************************************************************
 */
static void DemoCtIoMode5(void)
{
    stc_ct_pwm_config_t stcPwmConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();
    Gpio_SetFunc_TIOA1_0_OUT();
    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode5);
    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigRising;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartEnable;
    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 999); /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel0, 199);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteCycleVal(CtChannel1, 999); /* Cycle = (1+m)*PWM clock cycle   */
    Ct_Pwm_WriteDutyVal(CtChannel1,  199); /* Duty = (1+m)*PWM clock cycle   */

    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);

    /* Enable Simultaneously  */
    Ct_SetSimultaneousStart(0x0003);
    while(1);
}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_6)

/**
 *******************************************************************************
 ** \brief CT IO mode 6 demo code
 *******************************************************************************
 */
static void DemoCtIoMode6(void)
{
    stc_ct_pwm_config_t stcPwmConfig;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOA0_0();
    Gpio_SetFunc_TIOA1_0_OUT();

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode6);
    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig, (uint32_t)(sizeof(stcPwmConfig)));

    /* Initialize PWM timer  */
    stcPwmConfig.enPres = PwmPresNone;
    stcPwmConfig.enMode = PwmContinuous;
    stcPwmConfig.enExtTrig = PwmExtTrigFalling;
    stcPwmConfig.enOutputMask = PwmOutputNormal;
    stcPwmConfig.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig.enRestartEn = PwmRestartDisable;
    Ct_Pwm_Init(CtChannel0, &stcPwmConfig);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 999); /* Cycle = (1+m)*PWM clock cycle  */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel0, 199);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteCycleVal(CtChannel1, 199); /* Cycle = (1+m)*PWM clock cycle   */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel1,  99);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 25us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 12.5us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 12.5ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 12.2ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */

    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);

    /* Software trigger  */
    Ct_SetSimultaneousStart(0x0001);
    while(1);

}
#endif

#if (DEMO_MODE == DEMO_CT_IOMODE_7)

/**
 *******************************************************************************
 ** \brief CT IO mode 7 demo code
 *******************************************************************************
 */
static void DemoCtIoMode7(void)
{
    stc_ct_pwm_config_t stcPwmConfig0, stcPwmConfig1;

    /* Set Composite Timer  IO port  */
    Gpio_SetFunc_TIOB0_0();
    Gpio_SetFunc_TIOA0_0();
    Gpio_SetFunc_TIOA1_0_OUT();

    /* Set requested I/O mode  */
    Ct_ConfigIOMode(CtChannel0, CtIoMode7);
    /* Clear structures  */
    ddl_memclr((uint8_t *)&stcPwmConfig0, (uint32_t)(sizeof(stcPwmConfig0)));
    ddl_memclr((uint8_t *)&stcPwmConfig1, (uint32_t)(sizeof(stcPwmConfig1)));

    /* Initialize PWM timer  */
    stcPwmConfig0.enPres = PwmPresNone;
    stcPwmConfig0.enMode = PwmContinuous;
    stcPwmConfig0.enExtTrig = PwmExtTrigFalling;
    stcPwmConfig0.enOutputMask = PwmOutputNormal;
    stcPwmConfig0.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig0.enRestartEn = PwmRestartDisable;

    stcPwmConfig1.enPres = PwmPresNone;
    stcPwmConfig1.enMode = PwmContinuous;
    stcPwmConfig1.enExtTrig = PwmExtTrigFalling;
    stcPwmConfig1.enOutputMask = PwmOutputNormal;
    stcPwmConfig1.enOutputPolarity = PwmPolarityLow;
    stcPwmConfig1.enRestartEn = PwmRestartDisable;

    Ct_Pwm_Init(CtChannel0, &stcPwmConfig0);
    Ct_Pwm_Init(CtChannel1, &stcPwmConfig1);

    /* Set cycle and duty value  */
    Ct_Pwm_WriteCycleVal(CtChannel0, 1999);/* Cycle = (1+m)*PWM clock cycle   */
                                     /* 500us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 250us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 250ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 244ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel0,  999); /* Duty = (1+m)*PWM clock cycle   */
                                     /* 250us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 125us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 125ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 122ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteCycleVal(CtChannel1, 199); /* Cycle = (1+m)*PWM clock cycle   */
                                     /* 50us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 25us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 25ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 24.4ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */
    Ct_Pwm_WriteDutyVal(CtChannel1,  99);  /* Duty = (1+m)*PWM clock cycle  */
                                     /* 25us if Master Clock = 16MHz; HCLK = Master Clock / 2 = 8MHz;  PCLK0 = HCLK / 2 = 4MHz;  */
                                     /* 12.5us if Master Clock = 32MHz(Main Clock ); HCLK = Master Clock / 2 = 16MHz;  PCLK0 = HCLK / 2 = 8MHz;  */
                                     /* 12.5ms if Master Clock = 32KHz(Low Speed Clock); HCLK = Master Clock / 2 = 16kHz;  PCLK0 = HCLK / 2 = 8KHz;  */
                                     /* 12.2ms if Master Clock = 32768Hz(Subclock); HCLK = Master Clock / 2 = 16384kHz;  PCLK0 = HCLK / 2 = 8192Hz;  */

    /* Enable count operatoin  */
    Ct_Pwm_EnableCount(CtChannel0);
    Ct_Pwm_EnableCount(CtChannel1);

    /* Software trigger  */
    //Ct_Pwm_EnableSwTrig(CtChannel0); /* trigger start after 1.5ms  */
    while(1);
}
#endif

/*******************************************************************************
 * Global Functions
 ******************************************************************************/

/**
 *******************************************************************************
 ** \brief  Main function of CT IO mode sample for HC32L15 series.
 **
 ** \param  none
 ** \retval uint32_t return value, if needed
 ******************************************************************************/
int32_t main(void)
{
    Clk_SwitchTo(ClkHICR);

#if (DEMO_MODE == DEMO_CT_IOMODE_0)
    DemoCtIoMode0();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_1)
    DemoCtIoMode1();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_2_3)
    DemoCtIoMode23();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_2_8)
    DemoCtIoMode28();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_4)
    DemoCtIoMode4();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_5)
    DemoCtIoMode5();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_6)
    DemoCtIoMode6();
#endif
#if (DEMO_MODE == DEMO_CT_IOMODE_7)
    DemoCtIoMode7();
#endif

    while(1)
    {
        ;
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/

