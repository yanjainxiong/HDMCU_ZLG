/*******************************************************************************
 * Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
 *
 * This software is owned and published by:
 * Huada Semiconductor Co.,Ltd ("HDSC").
 *
 * BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
 * BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
 *
 * This software contains source code for use with HDSC
 * components. This software is licensed by HDSC to be adapted only
 * for use in systems utilizing HDSC components. HDSC shall not be
 * responsible for misuse or illegal use of this software for devices not
 * supported herein. HDSC is providing this software "AS IS" and will
 * not be responsible for issues arising from incorrect user implementation
 * of the software.
 *
 * Disclaimer:
 * HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
 * REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
 * ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
 * WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
 * WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
 * WARRANTY OF NONINFRINGEMENT.
 * HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
 * NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
 * LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
 * LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
 * INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
 * SAVINGS OR PROFITS,
 * EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
 * INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
 * FROM, THE SOFTWARE.
 *
 * This software may be replicated in part or whole for the licensed use,
 * with the restriction that this Disclaimer and Copyright notice must be
 * included with each copy of this software, whether used in part or whole,
 * at all times.
 */
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for lcd demonstration.
 **        Get more details from readme text.
 **
 **   - 2016-02-16  1.0  QCP First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "lcd.h"

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief LCD initialization configuration
**        mode: 8 com, 22 seg, duty cycle, a third bise 1/8
 **
 ** \retval en_result_t return value, if needed
 **
 ******************************************************************************/
en_result_t Lcd_InitFunc(void)
{
     /* Initialize a variable declaration*/
     stc_lcd_configtypedef_t  stcLcdInitconfig;
     /* The function returns the state*/
     en_result_t  enresult =  Error;
     
     /* Clear structure data*/
     ddl_memclr(&stcLcdInitconfig,sizeof(stcLcdInitconfig));
     
     /* LCD clock selected internal RC*/
     stcLcdInitconfig.enLcdDisplayClkSel  =  LcdClkSelInRc;
     /* The frame refresh rate select 128hz*/
     stcLcdInitconfig.enLcdFrameRerateSel =  LcdFrameReRateSel128Hz;
     /* LCD working mode set,include com��bias��duty��waveform��set*/
     stcLcdInitconfig.enLcdWorkModeSel  = Lcd_4Com_1Div4Duty_1Div3bias_TypeA_Max40Seg;
     /* LCD drive circuit selection,include in R�� Ex R �� Ex C�� Register (R03��R13��R23��R33��R43)driving voltagesetting*/ 
     /* LCD drive circuit select,in R*/
     stcLcdInitconfig.stcLcdDriveCircuitSel.enLcdDriveCirSel = LcdBiasCircuitSelInRes; 
     /* LCD contrast select,Contrast 100%*/ 
     stcLcdInitconfig.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirContrastSel = LcdContrastSel100per;
     /* LCD Charge time select,Charging time 1 CLK*/   
     stcLcdInitconfig.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirChargTimeSel = LcdRChargTimSel1Clk;
     /* LCD Charge mode select,Quick charging mode*/   
     stcLcdInitconfig.stcLcdDriveCircuitSel.stcLcdInRCirConfig.enLcdInRCirChargModeSel = LcdRChargModeSelFast;  
     /* LCD drive power select Normal*/
     stcLcdInitconfig.enLcdDrivePowerSel = LcdDrivePowSelNormal;
     
     /* LCD Port SEG0~SEG21 config*/
     stcLcdInitconfig.u8Seg0_Seg7Config  = 0xFF;
     stcLcdInitconfig.u8Seg8_Seg15Config = 0xFF;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE16 = ENABLE;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE17 = ENABLE;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE18 = ENABLE;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE19 = ENABLE;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE20 = ENABLE;
     stcLcdInitconfig.stcSeg16_Seg23Config.SEGE21 = ENABLE;
     
     /* According to the initialization configuration structure LCD registers*/
     enresult = Lcd_InitConfig( &stcLcdInitconfig );
     
     return enresult;
}

/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \retval uint32_t return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{    
    /* Lhe system clock configuration */
    M0P_WSUNIT->CLK_CTL2_f.LCDCKE = 1;  
    /* LCD initialization configuration*/
    Lcd_InitFunc();    
    /* LCD Enable*/
    Lcd_Cmd( ENABLE );
    /* LCD Full DDRAM display*/
    Lcd_FullWrite();
    
    while (1)
    {
#if 0      
       /* LCD Full DDRAM Clear*/ 
       Lcd_FullClear();
       /* LCD 100ms Time refresh*/ 
       delay1ms(2000); 
#endif
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/


