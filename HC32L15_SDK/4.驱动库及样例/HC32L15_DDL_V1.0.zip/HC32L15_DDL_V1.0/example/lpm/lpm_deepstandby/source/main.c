/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** This example demonstrates the process of idle mode.
 **
 **   - 2016-11-1  1.0   First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "lpm.h"
#include "rtc.h"
#include "clk.h"
#include "gpio.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define LED_INI() Gpio_InitIO(5,0,GpioDirOut,TRUE,FALSE)
#define LED_ON() Gpio_SetIO(5,0,TRUE)
#define LED_OFF() Gpio_SetIO(5,0,FALSE)


/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
uint8_t u8TimerIrqtFlag = 0;

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/


/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/


/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief RTC Timer Interrupt callback function
 **
 ******************************************************************************/
static void SampleRtcTimerCb(void)
{
    // Set timer interruption flag
    u8TimerIrqtFlag = TRUE;
}

/**
 ******************************************************************************
 ** \brief Configure and start RTC
 ******************************************************************************/
static void InitRtc(void)
{
    stc_rtc_config_t stcRtcConfig;
    stc_rtc_irq_en_t stcRtcEn;
    stc_rtc_irq_cb_t stcRtcCb;
    stc_rtc_time_t stcRtcTime;
    stc_rtc_timer_t stcRtcTimer;

    // Clear structures
    DDL_ZERO_STRUCT(stcRtcConfig);
    DDL_ZERO_STRUCT(stcRtcEn);
    DDL_ZERO_STRUCT(stcRtcCb);
    DDL_ZERO_STRUCT(stcRtcTime);
    DDL_ZERO_STRUCT(stcRtcTimer);

    // Time setting (23:59:00 5th of January 2015)
    stcRtcTime.u8Second         = 0;                            // Second      : 00
    stcRtcTime.u8Minute         = 59;                           // Minutes     : 59
    stcRtcTime.u8Hour           = 23;                           // Hour        : 23
    stcRtcTime.u8Day            = 5;                            // Date        : 5th
    stcRtcTime.u8DayOfWeek      = RtcMonday;                    // Week        : monday
    stcRtcTime.u8Month          = RtcJanuary;                   // Month       : January
    stcRtcTime.u16Year          = 2015;                         // Year        : 2015

    // Intialize RTC timer
    stcRtcTimer.enMode = RtcTimerPeriod;
    stcRtcTimer.u32TimerCycle = 30;                              // Generate interrupt every 30s

    // Configure interrupt
    stcRtcEn.bTimerIrq = TRUE;
    stcRtcCb.pfnTimerIrqCb = SampleRtcTimerCb;

    // Clear seconds interrupt flag
    u8TimerIrqtFlag = FALSE;

    // Initialize RTC configuration
    stcRtcConfig.bEnSuboutDivider = FALSE;
    stcRtcConfig.enRtccoSel = RtccoOutput1Hz;
    stcRtcConfig.enClkSel = RtcLSXTClk;
    stcRtcConfig.u32ClkPrescaler = RTC_CLOCK_PRES;

    stcRtcConfig.pstcTimeDate = &stcRtcTime;
    stcRtcConfig.pstcTimer = &stcRtcTimer;
    stcRtcConfig.pstcIrqEn = &stcRtcEn;
    stcRtcConfig.pstcIrqCb = &stcRtcCb;
    stcRtcConfig.bTouchNvic = TRUE;

    // Initialize the RTC
    Rtc_Init(&stcRtcConfig);

    // Start RTC
    Rtc_EnableFunc(RtcCount);

    // Enable timer
    Rtc_EnableFunc(RtcTimer);
}

/*!
 ******************************************************************************
 ** \brief  Time delay
 **
 ** \param  Cnt Count value
 **
 ** \return none
 ******************************************************************************
 *
 */
static void Delay(uint32_t Cnt)
{
    uint32_t i;
    for(;Cnt;Cnt--){
        for(i=SystemCoreClock/20000;i;i--)
        {
            ;
        }
    }
}


/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample
 **
 ******************************************************************************/
int32_t main(void)
{
    uint8_t i = 10;
    en_dstb_ret_cause_t enCause;
    stc_dstb_ret_cause_t stcCause;
    stc_clk_config_t stcCfg;

    // Clear structure
    DDL_ZERO_STRUCT(stcCause);
    DDL_ZERO_STRUCT(stcCfg);

    //Check the IO input value
    while(1 == M0P_GPIO->GET2_f.P26)
    {
    }

    enCause = Lpm_ReadDeepStbRetCause();

    //config clock
    stcCfg.enBaseClkDiv = ClkBaseDiv1;
    stcCfg.enAPB1Div = ClkApb1Div1;
    stcCfg.enclkWaitMain = ClkCswtMain1ms;
    stcCfg.enAPB0Div = ClkApb0Div1;
    stcCfg.enclkWaitSub = ClkCswtSub256ms;
    Clk_Enable(ClkLSXT, TRUE);

    /* Turn off LED */
    LED_INI();
    LED_OFF();

    /* Configure and start RTC */
    InitRtc();

    // Set deep standby wakeup cause
    stcCause.bRtcEn = 1u;
    Lpm_ConfigDeepStbRetCause(&stcCause);

    i = 10;
    if (DeepStbWkupPin0 == enCause)
    {
        i = 6;
       // while(1);
    }
    else if (DeepStbRtcInt == enCause)
    {
        i = 8;
        //while(1);
    }else{
        ;
    }

    while(i--)
    {
       LED_ON();
       Delay(100);
       LED_OFF();
       Delay(100);
    }

    /* Enter deep standby RTC / STOP mode */
    Lpm_GoToStandByMode(DeepStbRtcMode, TRUE);

    while(1)
    {
        ;
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/


