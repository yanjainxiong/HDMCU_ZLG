/*******************************************************************************
 * Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
 *
 * This software is owned and published by:
 * Huada Semiconductor Co.,Ltd ("HDSC").
 *
 * BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
 * BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
 *
 * This software contains source code for use with HDSC
 * components. This software is licensed by HDSC to be adapted only
 * for use in systems utilizing HDSC components. HDSC shall not be
 * responsible for misuse or illegal use of this software for devices not
 * supported herein. HDSC is providing this software "AS IS" and will
 * not be responsible for issues arising from incorrect user implementation
 * of the software.
 *
 * Disclaimer:
 * HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
 * REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
 * ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
 * WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
 * WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
 * WARRANTY OF NONINFRINGEMENT.
 * HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
 * NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
 * LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
 * LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
 * INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
 * SAVINGS OR PROFITS,
 * EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
 * INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
 * FROM, THE SOFTWARE.
 *
 * This software may be replicated in part or whole for the licensed use,
 * with the restriction that this Disclaimer and Copyright notice must be
 * included with each copy of this software, whether used in part or whole,
 * at all times.
 */
/******************************************************************************/
/** \file main.c
 **
 ** \brief The example for LVD wakeup function demonstration
 **
 **   - 2016-02-16  1.0  QCP First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "lvd.h"
#include "lpm.h"
#include "gpio.h"
#include "clk.h"

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define TEST_PORT       (2)
#define TEST_PIN        (6)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static uint32_t gu32Cnt = 0;

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 ******************************************************************************
 ** \brief  A function output a waveform
 **
 ** \param [in]  u8cnt  count
 **
 ** \retval  None
 **
 ******************************************************************************/
void Repeat(uint8_t u8cnt)
{
    while (u8cnt-- > 0)
    {
        Gpio_SetIO(TEST_PORT,TEST_PIN,1);
        delay1ms(1);
        Gpio_SetIO(TEST_PORT,TEST_PIN,0);
        delay1ms(1);
    }
}

/**
 ******************************************************************************
 ** \brief  LVD interrupt call back function
 **
 ** \retval  None
 **
 ******************************************************************************/
void LvdIrqCallback(void)
{
    Repeat(3);
    gu32Cnt++;
}

/**
 ******************************************************************************
 ** \brief  lvd1 polling function of project
 **
 ** \retval uint32_t return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_lvd1_config_t   stcCfg;
    stc_clk_rstcause_t  stcReset;
    uint32_t u32val = 0;

    Gpio_InitIO(TEST_PORT,TEST_PIN,GpioDirOut,FALSE,FALSE);

    Gpio_InitIO(3,7,GpioDirIn,FALSE,FALSE);
    Repeat(1);

    u32val = M0P_WSUNIT->WAKE_ISR;   //clear interrupt to prevent reset repeatly.
    u32val = M0P_WSUNIT->WAKE_RSR;

    u32val = u32val;                    //dis warning

    M0P_WSUNIT->LVD_CLR = 0;
    M0P_WSUNIT->LVD2_CLR = 0;

    DDL_ZERO_STRUCT(stcCfg);
    DDL_ZERO_STRUCT(stcReset);

    stcCfg.b10mvDly = FALSE;
    stcCfg.bFilter = FALSE;
  //stcCfg.enFilterTime = LvdFilter16ms;
    stcCfg.bLvdReset = FALSE;
    stcCfg.enInput = LvdInputVCC;
    stcCfg.enIrqType = Lvd1IrqLow;
    stcCfg.enThreshold = Lvd1TH2_50V;
    stcCfg.pfnIrqCbk = LvdIrqCallback;

    while (TRUE == Gpio_GetIO(3,7))
    {
        ;
    }

    Lvd1_Init(&stcCfg);

    M0P_WSUNIT->WAKE_IER_f.RELVDE = TRUE;

    Lvd_Enable(LvdType1);

    delay1ms(5);
    Repeat(2);
    Lpm_GoToStandByMode(DeepStbStopMode,FALSE);

    while (1)
    {
        ;
    }

}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
