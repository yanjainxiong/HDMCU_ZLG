/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief This example shows how to use the polling mode to TX/RX data through
 **        UART.
 **
 ** History:
 **   - 2016-12-08  1.0  QCP        version 1.0
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "uart.h"
#include "clk.h"
#include "gpio.h"

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
uint8_t u8TxData[10] = "HUADA MCU!";
uint8_t u8RxData[10];
uint8_t u8TxCnt = 0, u8RxCnt = 0;

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define CH0WITH1
//#define CH2WITH4
//#define CH5WITH6

#ifdef CH0WITH1
#define UARTTX  UARTCH0
#define UARTRX  UARTCH1
#endif

#ifdef CH2WITH4
#define UARTTX  UARTCH2
#define UARTRX  UARTCH4
#endif

#ifdef CH5WITH6
#define UARTTX  UARTCH5
#define UARTRX  UARTCH6
#endif

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief  Uart IO Configuration function
 **
 ******************************************************************************/
static void UartIoConfig(void)
{
#ifdef CH0WITH1
    Gpio_SetFunc_SIN0_1(x);
    Gpio_SetFunc_SOT0_1(x);

    Gpio_SetFunc_SIN1_0(x);
    Gpio_SetFunc_SOT1_0(x);
#endif
#ifdef CH2WITH4
    Gpio_SetFunc_SIN2S_0(x);
    Gpio_SetFunc_SOT2_0(x);

    Gpio_SetFunc_SIN4_1(x);
    Gpio_SetFunc_SOT4_1(x);
#endif
#ifdef CH5WITH6
    Gpio_SetFunc_SIN5_2(x);
    Gpio_SetFunc_SOT5_2(x);

    Gpio_SetFunc_SIN6_1(x);
    Gpio_SetFunc_SOT6_1(x);
#endif
}

/**
 *******************************************************************************
 ** \brief  main function for UART function demonstrate
 **
 ** \param [in]  None
 **
 ** \retval int32_t Return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_uart_config_t stcUartTxConfig;
    stc_uart_config_t stcUartRxConfig;
    uint8_t u8Cnt = 0;
    uint8_t u8Times;

    DDL_ZERO_STRUCT(stcUartTxConfig);
    DDL_ZERO_STRUCT(stcUartRxConfig);
    
    //Config the UART IO
    UartIoConfig();
    
    //Init the UART

    //Config the UART0
    stcUartTxConfig.bCarryEnable = FALSE;
    stcUartTxConfig.bCarryPolarity = FALSE;
    stcUartTxConfig.bCompensation = FALSE;
    stcUartTxConfig.bCtsWu = FALSE;
    stcUartTxConfig.bHwFlow = FALSE;
    stcUartTxConfig.bInvertData = FALSE;
    stcUartTxConfig.bTouchNvic = FALSE;
    stcUartTxConfig.bUseExtClk = FALSE;
    stcUartTxConfig.enBitDirection = UartDataLsbFirst;
    stcUartTxConfig.enDataLength = UartEightBits;
    stcUartTxConfig.enMode = UartNormal;
    stcUartTxConfig.enParity = UartParityEven;
    stcUartTxConfig.enStopBit = UartOneStopBit;
    stcUartTxConfig.u32BaudRate = 9600;
    
    Uart_Init(UARTTX, &stcUartTxConfig);
        
    Uart_EnableFunc(UARTTX, UartTx);

    //Config the UART1
    stcUartRxConfig.bCarryEnable = FALSE;
    stcUartRxConfig.bCarryPolarity = FALSE;
    stcUartRxConfig.bCompensation = FALSE;
    stcUartRxConfig.bCtsWu = FALSE;
    stcUartRxConfig.bHwFlow = FALSE;
    stcUartRxConfig.bInvertData = FALSE;
    stcUartRxConfig.bTouchNvic = FALSE;
    stcUartRxConfig.bUseExtClk = FALSE;
    stcUartRxConfig.enBitDirection = UartDataLsbFirst;
    stcUartRxConfig.enDataLength = UartEightBits;
    stcUartRxConfig.enMode = UartNormal;
    stcUartRxConfig.enParity = UartParityEven;
    stcUartRxConfig.enStopBit = UartOneStopBit;
    stcUartRxConfig.u32BaudRate = 9600;
    
    Uart_Init(UARTRX, &stcUartRxConfig);
        
    Uart_EnableFunc(UARTRX, UartRx);

    //Send/receive the data between Channel 0 and 1
    //Channel 0 send and channle 1 receive
    for(u8Times=0;u8Times<10;u8Times++)
    {
        while(u8Cnt < 10)
        {
            while (TRUE != Uart_GetStatus(UARTTX, UartTxEmpty)) /* wait until TX buffer empty */
            {
                ;
            }
            Uart_SendData(UARTTX, u8TxData[u8Cnt]);  
            
            while(TRUE != Uart_GetStatus(UARTRX, UartRxFull)) /* wait until RX buffer full */
            {
                ;
            }
            u8RxData[u8Cnt] = Uart_ReceiveData(UARTRX);
            
            u8Cnt++;
        }
        if(0 != memcmp(u8TxData,u8RxData,10))
        {
            while(1)
            {
                ;
            }
        }
    }
    
    Uart_DeInit(UARTTX, TRUE);
    Uart_DeInit(UARTRX, TRUE);

    while(1)
    {
        ;
    }
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
