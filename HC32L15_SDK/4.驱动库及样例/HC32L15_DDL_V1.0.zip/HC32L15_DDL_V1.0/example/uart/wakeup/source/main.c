/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief This example shows how to use the UART low power recive function to 
 **        wake up the MCU from low power mode.
 **
 ** History:
 **   - 2016-12-08  1.0  QCP        version 1.0
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "uart.h"
#include "lpm.h"
#include "clk.h"
#include "gpio.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define UART_BAUDRATE   (9600)

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
uint8_t u8TxData[10] = "HUADA MCU!";
uint8_t u8RxData[10];
uint8_t u8TxCnt = 0, u8RxCnt = 0;

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
#define GPIO1_OutputIni(x) bM0P_GPIO_FN0_P06 = 0;bM0P_GPIO_DIR0_P06 = 1;bM0P_GPIO_PU0_P06 = 1;bM0P_GPIO_ODR0_P06 = 0;bM0P_GPIO_SET0_P06 = 0
#define GPIO1_Output(x)  bM0P_GPIO_SET0_P06  = x
#define GPIO1_Polling()  bM0P_GPIO_SET0_P06 ^= 1

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief  Uart IO Configuration function
 **
 ******************************************************************************/
static void UartIoConfig(void)
{
    //Disable Analog function
    M0P_GPIO->ANALOG = 0;
    //Config the SIN4_0
    M0P_GPIO->FN7_f.P71 = 1;
    M0P_GPIO->FN_SEL07_f.SIN4S = 1;
}

/**
 *******************************************************************************
 ** \brief  UART4 RX interrupt callback function
 ******************************************************************************/
void Uart4RxIntCallback(void)
{
    volatile uint16_t u16Temp;
    
    u16Temp = M0P_MSC4_UART->RXDR;

    Uart_DisableIrq(UARTCH4,UartRxIrq);
}

/**
 *******************************************************************************
 ** \brief  main function for UART function demonstrate
 **
 ** \param [in]  None
 **
 ** \retval int32_t Return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_uart_config_t stcUart4Config;
    stc_uart_irq_cb_t stcUart4IrqCb;
    stc_uart_irq_en_t stcIrqEn;
    
    //Set the test IO
    //High for start
    //Low for enter the low power mode
    //High for back
    GPIO1_OutputIni(0);
    GPIO1_Output(1);

    //Init the Test IO pin, high for protect, low for start
    //P26 as IO
    M0P_GPIO->FN2_f.P26 = 0;
    //P26 as Input
    M0P_GPIO->DIR2_f.P26 = 0;

    //Check the IO input value
    while(1 == M0P_GPIO->GET2_f.P26)
    {
    }

    GPIO1_OutputIni(0);
    GPIO1_Output(0);
        

    //Switch to Ext High Osc.
//    Clk_SwitchTo(ClkExtHcr);
    //Switch to Ext Low Osc.
    Clk_SwitchTo(ClkLSXT);

    M0P_WSUNIT->BGR_CTL_f.BGR_EN = 1;
    M0P_WSUNIT->CLK_CTL2_f.UARTCKE = 1;
    
    DDL_ZERO_STRUCT(stcUart4Config);
    DDL_ZERO_STRUCT(stcUart4IrqCb);
    DDL_ZERO_STRUCT(stcIrqEn);
    
    //Config the UART IO
    UartIoConfig();
    
    //Init the UART
    stcIrqEn.bRxIrq = TRUE;
    stcUart4IrqCb.pfnRxIrqCb = Uart4RxIntCallback;
    
    //Config the UART1
    stcUart4Config.bCarryEnable = FALSE;
    stcUart4Config.bCarryPolarity = FALSE;
    stcUart4Config.bCompensation = TRUE;
    stcUart4Config.bCtsWu = FALSE;
    stcUart4Config.bHwFlow = FALSE;
    stcUart4Config.bInvertData = FALSE;
    stcUart4Config.bTouchNvic = TRUE;
    stcUart4Config.bUseExtClk = FALSE;
    stcUart4Config.enBitDirection = UartDataLsbFirst;
    stcUart4Config.enDataLength = UartEightBits;
    stcUart4Config.enMode = UartNormal;
    stcUart4Config.enParity = UartParityNone;
    stcUart4Config.enStopBit = UartOneStopBit;
    stcUart4Config.u32BaudRate = 9600;
    stcUart4Config.pstcIrqCb = &stcUart4IrqCb;
    stcUart4Config.pstcIrqEn = &stcIrqEn;
    stcUart4Config.u16CompenConf = 0x0155;
    
    Uart_Init(UARTCH4, &stcUart4Config);
        
    //Enable the RX function
    Uart_EnableFunc(UARTCH4, UartRx);

    //Enter the RTC Standby mode
    Lpm_GoToStandByMode(StbIdleMode, TRUE);
    
    //Wakeup by receive the data
    //Send back the received data
    GPIO1_OutputIni(0);
    GPIO1_Output(1);

    while(1)
    {
        ;
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
