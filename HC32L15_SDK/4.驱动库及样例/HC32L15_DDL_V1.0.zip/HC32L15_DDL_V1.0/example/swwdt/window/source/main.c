/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file main.c
 **
 ** \brief this example shows how to use the window mode of the Software
 **        watchdog timer.
 **
 ** History:
 **   - 2016-12-08  1.0  QCP        version 1.0
 **
 ******************************************************************************/

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "swwdt.h"

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
uint32_t u32Value;
volatile uint32_t u32Count;
volatile uint8_t  u8Index;

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
static volatile uint8_t u8SwwdtActive;

// Table to store status of window watchdog error
static volatile uint8_t au8ErrorStatus[2] = {0, 0};

// Timing table for reloading to watchdog timer
// Please use these values when debugging performs by flash and optimization is not used.
static const volatile uint32_t au32CountValue[2]  = {
    500000,    // Interruption will occur
    1400000    // Interruption will not occur
};

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 *******************************************************************************
 ** \brief  Software watchdog interrupt function
 **
 ******************************************************************************/
static void WdtSwCallback(void)
{
    // Stop software watchdog (*)
    Swwdt_Stop();

    // Clear interrupt
    Swwdt_Feed();

    // Software watchdog in-acitve
    u8SwwdtActive = FALSE;

    // (*)Software watchdog has to be stopped since interruption occurs,
    //    when interruption cause was cleared and watchdog counter was reloaded.
}

/**
 *******************************************************************************
 ** \brief  delay function
 **
 ******************************************************************************/
void Delay(void)
{
    uint32_t i = 0;

    while(i < 100)
    {
        i++;
    }
}

/**
 *******************************************************************************
 ** \brief  main function for swwdt function demonstrate
 **
 ** \param [in]  None
 **
 ** \retval int32_t Return value, if needed
 **
 ******************************************************************************/
int32_t main(void)
{
    stc_swwdt_config_t stcSwwdtConfig;

    DDL_ZERO_STRUCT(stcSwwdtConfig);
    u8SwwdtActive = FALSE;
    // Initialize Software watchdog
    stcSwwdtConfig.u32LoadValue = 20000000;     ///< Timer interval   
    stcSwwdtConfig.bResetEnable = FALSE;         ///< Enables SW watchdog reset
    stcSwwdtConfig.bWinWdtEnable = TRUE;       ///< Enables Window watchdog mode  
    stcSwwdtConfig.bWinWdtResetEnable = FALSE;
    stcSwwdtConfig.u8TimingWindow = en_swwdt_timing_window_50;
    stcSwwdtConfig.pfnSwwdtIrqCb = WdtSwCallback;

    if (Ok != Swwdt_Init((stc_swwdt_config_t *)&stcSwwdtConfig))
    {
        while (1)
        {
            ;
        }
    }

    u8Index = 0;
    while (2 > u8Index)
    {
        // Restart software watchdog
        Swwdt_Start();
        u8SwwdtActive = TRUE;
        // Adjust the timing for reloading watchdog counter
        u32Count = au32CountValue[u8Index];
        while (0 != (--u32Count))
        {
            continue;
        }
        __disable_irq();
        // Clear interrupt and reload watchdog counter
        Swwdt_Feed();
        __enable_irq();
        // Insert cycle for interrupt
        Delay();
        // If watchdog is in-active, error is occured
        if (FALSE == u8SwwdtActive)
        {
            // Error status set
            au8ErrorStatus[u8Index] = 1;
        }
        u8Index++;
        __disable_irq();
        // If watchdog is active...
        if (TRUE == u8SwwdtActive)
        {
            // Stop software watchdog and clear interrupt
            Swwdt_Stop();
            
            Swwdt_Feed();
        }
        __enable_irq();
    }

    // wait for interrupts
    while(1)
    {
        ;
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
