2017-06-28      baseline for release. 
==misra compliance exception==
beside cmsis-core violation, in "required" items, DDL(not included sample
    project files) aslo violates:

1.1    compiler is not configured to compile C89/C95 code



2.2     Source code shall only use /* �� */ style comments.
        -----
        for doxygen issue, need different comment sytle.

5.1     more than 31 characters
        ---
        header file issue.

        
6.4     Bit fields shall only be defined to be of type unsigned int or signed 
        int.
        -----
        in the headfile, some register is not 32bit access. 

            
8.1     Functions shall have prototype declarations and the prototype 
        shall be visible at both the function definition and call.
        -----
        interrupt callbacks are weak defined, not have prototype file.

8.10    All declarations and definitions of objects or functions at file 
        scope shall have internal linkage unless external linkage is 
        required.
        -----
        Complexity 
        
10.1    Implicit and explicit type conversions
        -----
        Complexity 
        
10.3    Dangerous type conversions
        -----
        Complexity 

14.3    Before preprocessing, a null statement shall only occur on a line 
        by itself
        -----
        ASSERT() macro.

14.5    The continue statement shall not be used.
        -----
        Complexity 
        
14.6    For any iteration statement there shall be at most one break
        statement used for loop termination
        -----
        Complexity 

14.7    a function should have a single point of exit
        ---
        code sequence

        
17.4    Array indexing shall be the only allowed form of pointer arithmetic.
        -----
        Complexity 
        
20.2    The names of standard library macros, objects and functions 
        shall not be reused.
        -----
        Complexity
        
20.12   The time handling functions of library <time.h> shall not be used.
        -----
        RTC

        
#cmsis part
18.4
19.1


        
        