/******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/

/******************************************************************************/
/** \file lcd_show.c
 **
 ** This source code supports the operation of lcd_show to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/

#include "lcd_show.h"
#include "lcd.h"


//LCD��ӦSEG���
const uint8_t LcdSegNum[] = {0, 1, 2, 5, 6, 7, 13, 20};
// Number 0-9
#if GDC04212
const uint8_t LcdNumMap[][2] =            
{
    {0x5,0xF},    /* 0 */
    {0x0,0x6},    /* 1 */
    {0x6,0xB},    /* 2 */
    {0x2,0xF},    /* 3 */
    {0x3,0x6},    /* 4 */
    {0x3,0xD},    /* 5 */
    {0x7,0xD},    /* 6 */
    {0x0,0x7},    /* 7 */
    {0x7,0xF},    /* 8 */
    {0x3,0xF},    /* 9 */
    {0x5,0x9}     /* C */      
};
#endif

#if S401M16TF
const uint8_t LcdNumMap[][2] =            
{
    {0xB,0xE},    /* 0 */
    {0xA,0x0},    /* 1 */
    {0x7,0xC},    /* 2 */
    {0x5,0xE},    /* 3 */
    {0xC,0x6},    /* 4 */
    {0xD,0xA},    /* 5 */
    {0xF,0xA},    /* 6 */
    {0x0,0xE},    /* 7 */
    {0xF,0xE},    /* 8 */
    {0xD,0xF},    /* 9 */
    {0xB,0x8}     /* C */      
};
#endif

//init lcd 
void LCD_Init(void)
{
    stc_lcd_cfg_t  stcLcdInitconfig;
    ddl_memclr(&stcLcdInitconfig,sizeof(stcLcdInitconfig));
    
    /*LCD clock selected internal RC*/
    stcLcdInitconfig.enLcdClk  =   LcdClkLICR;
    /*The frame refresh rate select 128hz*/
    stcLcdInitconfig.enLcdRefreshRate =  LcdRefreshRate512Hz; 
    /*LCD working mode set,include com��bias��duty��waveform��set*/    
    stcLcdInitconfig.enLcdWorkMode  = Lcd_4Com_1Div4Duty_1Div3bias_TypeA_Max40Seg;  
    /*LCD drive circuit select,in R*/    
    stcLcdInitconfig.stcLcdDriveCircuit.enDriveCircuit = LcdBiasCircuitInRes;
    /*LCD contrast select,Contrast 100%*/
    stcLcdInitconfig.stcLcdDriveCircuit.stcLcdInrCfg.enContrast = LcdContrast100per; 
    stcLcdInitconfig.stcLcdDriveCircuit.stcLcdInrCfg.enChargingTime = LcdChargeTime1Clk; /*LCD Charge time select,Charging time 1 CLK*/
    stcLcdInitconfig.stcLcdDriveCircuit.stcLcdInrCfg.enChargingMode = LcdChargeModeFast;/*LCD Charge mode select,Quick charging mode*/
    stcLcdInitconfig.enLcdDriveCap = LcdDriveCapabilityNormal;                                              /*LCD drive power select Normal*/
    
    /*LCD Port config*/
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE0 = ENABLE;
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE1 = ENABLE;
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE2 = ENABLE;
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE5 = ENABLE;
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE6 = ENABLE;
    stcLcdInitconfig.stcSeg0_Seg7Config.SEGE7 = ENABLE;
    stcLcdInitconfig.stcSeg8_Seg15Config.SEGE13 = ENABLE;
    stcLcdInitconfig.stcSeg16_Seg23Config.SEGE20 = ENABLE;
    
    Lcd_InitConfig( &stcLcdInitconfig );
    Lcd_Cmd(ENABLE);
}

/*
 *index: 0-3
 *value: 0-9
 *dot: С����  
*/
en_result_t LCD_SetShowValue(uint8_t index,uint8_t value,LcdDotFun dot)
{
    if((index>3) | (value>10))
        return Error;
    
    if(dot == LcdDotEnable)      //dot
    {
        #if S401M16TF
          LCD_WriteDdramIndexByte(LcdSegNum[index*2], LcdNumMap[value][0]);
          LCD_WriteDdramIndexByte(LcdSegNum[index*2+1], LcdNumMap[value][1]|0x1);
        #else
          LCD_WriteDdramIndexByte(LcdSegNum[index*2], LcdNumMap[value][0]|0x8);
          LCD_WriteDdramIndexByte(LcdSegNum[index*2+1],LcdNumMap[value][1]);
        #endif
    }
    else //number
    {
          LCD_WriteDdramIndexByte(LcdSegNum[index*2], LcdNumMap[value][0]);
          LCD_WriteDdramIndexByte(LcdSegNum[index*2+1],LcdNumMap[value][1]);    
    }
    return Ok;
}

//full show
void LCD_FullScreen(void)
{
    Lcd_FullWrite();
}

//clear show
void LCD_ClearScreen(void)
{
    Lcd_FullClear();
}
  









