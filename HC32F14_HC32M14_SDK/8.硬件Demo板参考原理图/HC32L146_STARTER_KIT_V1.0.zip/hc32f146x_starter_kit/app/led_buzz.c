/******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file led_buzz.c
 **
 ** This source code supports the operation of led and buzz to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "led_buzz.h"
#include "ct.h" 
#include "gpio.h"
#include "cc.h"

/*********************************************************
 *****                      LED                      *****
*********************************************************/

//PWM ID
uint8_t gPwmIndex;		
//PWM DUTY
uint8_t gIndexWave[] = {1,1,2,2,3,4,6,8,10,14,19,25,33,44,59,80,
	107,143,191,255,255,191,143,107,80,59,44,33,25,19,14,10,8,6,4,3,2,2,1,1};


/**
 ******************************************************************************
 ** \brief PWM underflow interrupt handler
 ******************************************************************************
 */
static void PwmUnderflowIrqHandler(void)
{
    static uint8_t pwmCnt = 0;
    
        if(++pwmCnt >= 10)      //��80ms
        {
            pwmCnt = 0;
            Ct_Pwm_WriteDutyVal(PWM_LED3_CHANNEL, gIndexWave[gPwmIndex]);
            if(++gPwmIndex >= 40)
                gPwmIndex = 0;
        }
}

//init led
void LED_Init(void)
{
#if LED_WORK_MODE == LED_NORMAL_MODE
    Gpio_InitIO(LED_GPIO_PORT,LED_GPIO_PIN,GpioDirOut,TRUE,FALSE);    
    LED3_Off();
#else
    stc_ct_pwm_config_t stc_ct_cfg;
    stc_pwm_irq_en_t stc_irq_en;
    stc_pwm_irq_cb_t stc_irq_cb;
   
    DDL_ZERO_STRUCT(stc_ct_cfg);
    DDL_ZERO_STRUCT(stc_irq_en);
    DDL_ZERO_STRUCT(stc_irq_cb);
    
    Gpio_SetFunc_TIOA2_1_OUT();
    /* Set Composite Timer  I/O mode   */
    Ct_ConfigIOMode(PWM_LED3_CHANNEL, CtIoMode0);
       
    stc_irq_en.bPwmTrigIrq = FALSE;
    stc_irq_en.bPwmDutyMatchIrq = FALSE;
    stc_irq_en.bPwmUnderflowIrq = TRUE;
    
    stc_irq_cb.pfnPwmTrigIrqCb = NULL;
    stc_irq_cb.pfnPwmDutyMatchIrqCb = NULL;
    stc_irq_cb.pfnPwmUnderflowIrqCb = &PwmUnderflowIrqHandler;
     
    stc_ct_cfg.enPres = PwmPres1Div128;
    stc_ct_cfg.enRestartEn = PwmRestartEnable;
    stc_ct_cfg.enOutputMask = PwmOutputNormal;
    stc_ct_cfg.enExtTrig = PwmExtTrigDisable;
    stc_ct_cfg.enOutputPolarity = PwmPolarityHigh;
    stc_ct_cfg.enMode = PwmContinuous;
    stc_ct_cfg.pstcPwmIrqEn = &stc_irq_en;
    stc_ct_cfg.pstcPwmIrqCb = &stc_irq_cb;
    stc_ct_cfg.bTouchNvic = TRUE;
    
    Ct_Pwm_Init(PWM_LED3_CHANNEL, &stc_ct_cfg);

    Ct_Pwm_WriteCycleVal(PWM_LED3_CHANNEL, 255);     
    Ct_Pwm_WriteDutyVal(PWM_LED3_CHANNEL, 255); 
#endif
}

void LED3_Off(void)
{
#if LED_WORK_MODE == LED_NORMAL_MODE
    Gpio_SetIO(LED_GPIO_PORT,LED_GPIO_PIN,TRUE);
#else
    Ct_Pwm_DisableCount(PWM_LED3_CHANNEL);  
    Ct_Pwm_WriteDutyVal(PWM_LED3_CHANNEL,0);
#endif            
}

void LED3_On(void)
{
#if LED_WORK_MODE == LED_NORMAL_MODE
    Gpio_SetIO(LED_GPIO_PORT,LED_GPIO_PIN,FALSE);
#else
    gPwmIndex = 0; 
    Ct_Pwm_EnableCount(PWM_LED3_CHANNEL);       /* Enable count operatoin  */
    Ct_Pwm_EnableSwTrig(PWM_LED3_CHANNEL);      /* Start triggered by software  */      
#endif    
}


/*********************************************************
 *****                      BUZZ                     *****
*********************************************************/

/**
 ******************************************************************************
 ** \brief CC callback
 **
 ** \return 
 ******************************************************************************/
void Cc1IrqCbk(void)
{
    static uint8_t u8Flag = 0;
    u8Flag = !u8Flag;
    Gpio_SetIO(BUZZ_PORT, BUZZ_PIN, u8Flag);   
}

//CC drive beep
static const stc_cc_config_t stcCcChannelConfig = {
    HSXT,                // Periodic mode
    TRUE,                // Prescaler dividor 
    Modulus3,            // 
    Ck0,
    TRUE,                // irq enable
    Cc1IrqCbk,
    TRUE,                // enable nvic
};

//init buzz
void Buzz_Init(void)
{
  Gpio_InitIO(BUZZ_PORT, BUZZ_PIN, GpioDirOut, FALSE, FALSE);//init beep pin
  Cc_Init((stc_cc_config_t *)&stcCcChannelConfig);
  Cc_WriteLoadVal(30);
}

void Buzz_Off(void)
{
  Cc_DisableCount();
}

void Buzz_On(void)
{
   Cc_EnableCount();
}


