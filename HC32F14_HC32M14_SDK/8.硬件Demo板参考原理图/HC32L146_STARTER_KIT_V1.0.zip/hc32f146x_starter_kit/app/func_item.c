/*******************************************************************************
* Copyright (C) 2016, Huada Semiconductor Co.,Ltd All rights reserved.
*
* This software is owned and published by:
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC
* components. This software is licensed by HDSC to be adapted only
* for use in systems utilizing HDSC components. HDSC shall not be
* responsible for misuse or illegal use of this software for devices not
* supported herein. HDSC is providing this software "AS IS" and will
* not be responsible for issues arising from incorrect user implementation
* of the software.
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS),
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING,
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED
* WARRANTY OF NONINFRINGEMENT.
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT,
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA,
* SAVINGS OR PROFITS,
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED
* FROM, THE SOFTWARE.
*
* This software may be replicated in part or whole for the licensed use,
* with the restriction that this Disclaimer and Copyright notice must be
* included with each copy of this software, whether used in part or whole,
* at all times.
*/
/******************************************************************************/
/** \file func_item.c
 **
 ** This source code supports the operation of fun_item to sample 
 **
 ** History:
 **   - 2017-06-27	1.0  HeChun   First version.
 **
 ******************************************************************************/
/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "includes.h"
#include "clk.h"

/*****************************************************************************/
/* Local pre-processor symbols/macros ('#define')                            */
/*****************************************************************************/

/*****************************************************************************/
/* Global variable definitions (declared in header file with 'extern')       */
/*****************************************************************************/
uint8_t DecToAscii(uint8_t dat);
void UartSendAscii(uint8_t num4bits, uint32_t data);
void UartRxHandle(void);

/*****************************************************************************/
/* Local type definitions ('typedef')                                        */
/*****************************************************************************/

/*****************************************************************************/
/* Local function prototypes ('static')                                      */
/*****************************************************************************/

boolean_t PortTestReturn(void)
{
    return TRUE;
}

void PortTestHandle(void)
{

}

boolean_t SubClockTestReturn(void)
{
    if (M0P_CLOCK->CTRL_f.SUB_EN == TRUE)    /* Sub clock oscillator enabled ? */
    {     
        if(Clk_GetClkRdy(ClkLSXT) == FALSE) //Sub clock oscillation stable
        {
            UartWriteString((unsigned char *)"*                    The Sub Clock isn't stable                     *\r\n");  
            stcSysRun.stcMenuItem[1].pMenuItemWrite = ItemWrPara3;
        }
        else
        {
            stcSysRun.stcMenuItem[1].pMenuItemWrite = ItemWrPara2;
        }
    }
    else
    {
        UartWriteString((unsigned char *)"*         The firmware don't enable Sub Clock , please check        *\r\n");  
        stcSysRun.stcMenuItem[1].pMenuItemWrite = ItemWrPara3;
    }

    return TRUE;
}

void SubClockTestHandle(void)
{

}


boolean_t RgbLedTestReturn(void)
{ 
    uint16_t u16LedTimer;
    
    UartWriteString((unsigned char *)"  LED test started, Please observe the LED changes  \r\n\0");
    LED3_On();
    SysTick_TimerMax65535ms(&u16LedTimer, 0x0);
    while(TIME_OUT_FLAG != SysTick_TimerMax65535ms(&u16LedTimer,100));  //wait 1s show
    UartWriteString((unsigned char *)"  Press 'Enter' key to return  \r\n\0");
    while (1)
    {
        UartRxHandle();
        if ( TRUE == stcSysRun.UartRxFlag)
        {
            LED3_Off();
            stcSysRun.UartRxFlag = FALSE;
            return TRUE;
        }
    }
}



void RgbLedTestHandle(void)
{
    ;
}


boolean_t KeyTestReturn(void)
{
    uint16_t u16KeyTimer;
    
    SysTick_TimerMax65535ms(&u16KeyTimer, 0x00);
    while (1)
    {
        if ( NO_TIME_OUT_FLAG == SysTick_TimerMax65535ms(&u16KeyTimer,5000))
        {
            Key_ScanServe(&Key_stcKeyInfo);

            if( Release ==  Key_stcKeyInfo.enKeyValue)
            {
                UartWriteString("\r\n");
                return TRUE;
            }
        }
        else
        {
            UartWriteString((unsigned char *)"*       Key test is timeout, please check                           *\r\n\0");
            return FALSE;
        }
    }
}

void KeyTestHandle(void)
{
    ; 
}

boolean_t BuzzTestReturn(void)
{
    uint16_t u16BuzzTimer;
    
    UartWriteString((unsigned char *)"  BUZZ test started, Please listen to the voice  \r\n\0");
    Buzz_On();
    SysTick_TimerMax65535ms(&u16BuzzTimer, 0x0);
    while(TIME_OUT_FLAG != SysTick_TimerMax65535ms(&u16BuzzTimer,50));  //wait 0.5s sing
    UartWriteString((unsigned char *)"  Press 'Enter' key to return  \r\n\0");
    while (1)
    {
        UartRxHandle();
        if ( TRUE == stcSysRun.UartRxFlag)
        {
            Buzz_Off();
            stcSysRun.UartRxFlag = FALSE;
            return TRUE;
        }
    }
}
void BuzzTestHandle(void)
{
    ;
}

boolean_t TempAdcTestReturn(void)
{
    uint16_t u16AdcTimer;
    char txBuf[32];
    uint16_t u16AdcData;
    
    UartWriteString((unsigned char *)"    Temperature test started      \r\n\0");
    UartWriteString((unsigned char *)"    Please check the data:        \r\n\0");
    SysTick_TimerMax65535ms(&u16AdcTimer, 0x0);
    LCD_ClearScreen();
    while (1)
    {
        if ( TIME_OUT_FLAG == SysTick_TimerMax65535ms(&u16AdcTimer,100))
        {
            SysTick_TimerMax65535ms(&u16AdcTimer, 0x00);
            u16AdcData = TempAdc_GetValue();
            sprintf(txBuf,"*    current Temperature:%d.%dC",u16AdcData/10,u16AdcData%10);
            UartWriteString((uint8_t*)txBuf);
            UartWriteString((unsigned char *)"       Press 'Enter' Key Return to MainMenu           *\r\n\0");
        }
        UartRxHandle();
        if ( TRUE == stcSysRun.UartRxFlag)
        {
            LCD_ClearScreen();
            stcSysRun.UartRxFlag = FALSE;
            return TRUE;
        }
    }  
}

void TempAdcTestHandle(void)
{
    ;
}

boolean_t EepromTestReturn(void)
{
    uint8_t u8WriteBuf[16] = "023456789abcdefg";
    uint8_t u8ReadBuf[16] = {0};
    
    UartWriteString((unsigned char *)"  EEPROM test started     \r\n\0");
    I2cEeprom_Write(0x00,u8WriteBuf,16);
    delay1ms(20);
    I2cEeprom_Read(0x00,u8ReadBuf,16);
    if(Ok !=  memcmp(u8WriteBuf, u8ReadBuf, 16))
    {
        UartWriteString((unsigned char *)"  EEPROM is error     \r\n\0");
        stcSysRun.stcMenuItem[6].pMenuItemWrite = ItemWrPara3;
    }
    else
    {
        UartWriteString((unsigned char *)"  EEPROM is OK     \r\n\0");
        stcSysRun.stcMenuItem[6].pMenuItemWrite = ItemWrPara2;
    }
    
    return TRUE;
}

void EepromTestHandle(void)
{
    ;
}


boolean_t LcdTestReturn(void)
{
    uint16_t u16LcdTimer;
    uint16_t u16AdcData;
    
    UartWriteString("  Lcd  test started,Please observe the LCD display  \r\n\0");
    SysTick_TimerMax65535ms(&u16LcdTimer, 0x0);
    while(TIME_OUT_FLAG != SysTick_TimerMax65535ms(&u16LcdTimer,100));  //wait 1s 
    UartWriteString("  Press 'Enter' key to return  \r\n\0");
    while (1)
    {
        if ( TIME_OUT_FLAG == SysTick_TimerMax65535ms(&u16LcdTimer,100))
        {
          SysTick_TimerMax65535ms(&u16LcdTimer, 0x00);
          u16AdcData = TempAdc_GetValue();
          LcdShoTemperature(u16AdcData);
        }
        UartRxHandle();
        if ( TRUE == stcSysRun.UartRxFlag)
        {
           stcSysRun.UartRxFlag = FALSE;
           break;
        }
    }
    
    return TRUE;
}

void LcdTestHandle(void)
{
    ;
}


boolean_t CodecMicTestReturn(void)
{
    return TRUE;
}

void CodecMicTestHandle(void)
{
    ;
}

uint8_t DecToAscii(uint8_t dat)
{
    if (dat <= 9)
    {
        return (dat+'0');
    }
    
    return (dat+55);
}

void Float2Char(uint8_t *u8Str, float32_t f32FloatNumber, uint8_t u8IntValidWidth, uint8_t u8DotValidWidth)
{
    uint8_t i;    
    uint8_t u8OffSet = 0;
    float32_t t2 = 0.0;
    int16_t temp =(int16_t )f32FloatNumber/1;
    uint8_t au8Table[]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    if((f32FloatNumber < 0.001) && (f32FloatNumber > -0.001))
    {
        u8Str[0] = '0';        
        u8Str[0] = '.';
        u8Str[0] = '0';
        u8Str[0] = '0';
        u8Str[0] = '0';
        return;
    }
    
    if(f32FloatNumber < 0.00)
    {
        u8Str[0] = '-';
        u8OffSet = 1;
        f32FloatNumber *= (-1.0);
    }
    else
    {
        u8OffSet = 0;
    }
    
    for (i = 1; i<= u8IntValidWidth; i++)
    {
        if (temp == 0)
            u8Str[u8OffSet + u8IntValidWidth - i] = au8Table[0];
        else
            u8Str[u8OffSet + u8IntValidWidth - i] = au8Table[temp%10];
        temp = temp/10;
    }
    *(u8Str + u8OffSet + u8IntValidWidth) = '.';
    temp = 0;
    t2 = f32FloatNumber;
    for(i=1; i<= u8DotValidWidth; i++)
    {
        temp = (int16_t)(t2*10);
        u8Str[u8OffSet + u8IntValidWidth + i] = au8Table[temp%10];
        t2 = t2*10;
    }
    *(u8Str + u8OffSet + u8IntValidWidth + u8DotValidWidth + 1) = '\0';

    return;
}

void UartSendAscii(uint8_t num4bits, uint32_t data)
{
    unWordToNib_t unWordToNib;
    uint8_t Infor[11] = "0x    \0";
    uint8_t Result[11] = "0x    \0";
    uint8_t cnt;
    uint8_t place;
    
    if ( (num4bits >0x8) || (num4bits == 0x0) )
    {
        return;
    }
    
    place = 2;
    unWordToNib.Word = data;
  
    for (cnt=0; cnt<4; cnt++)
    {
        Infor[place++] = DecToAscii(unWordToNib.ByteToNib[3-cnt].NibH);
        Infor[place++] = DecToAscii(unWordToNib.ByteToNib[3-cnt].NibL);
    }
    
    place = 0x2;
    for (cnt=0; cnt<num4bits; cnt++)
    {
        Result[place + cnt] = Infor[10-num4bits+cnt];      
    }
    
    cnt = place + cnt;
    
    for ( ; cnt<10; cnt++)
    {
        Result[place + cnt++] = '\0';   
    }
    
    UartWriteString(Result);

    return;
}

void UartRxHandle(void)
{
    uint32_t Temp;
    uint32_t RxCnt;
    uint32_t ChgValue;
    uint8_t dat;
    
    if ( TRUE != stcUartRxBuf.RxFlg )
    {
        return;
    }
    
    RxCnt = stcUartRxBuf.RxCnt;
    
    if ( RxCnt == 0 )            // only enter key
    {
        stcSysRun.UartRxFlag = TRUE;
        stcSysRun.UartRxValid = FALSE;  
        stcSysRun.UartRxData = '\0';
        stcUartRxBuf.RxCnt = 0x0;
        stcUartRxBuf.RxFlg = FALSE;
        return;
    }
    
    else if ( (RxCnt > 0x2) && ('0' == stcUartRxBuf.UartRx[0]) && ('x' == stcUartRxBuf.UartRx[1]) )   // Input data is hexadecimal
    {
        ChgValue = 0x0;
        for ( Temp=2; Temp<RxCnt; Temp++)
        {
            dat = stcUartRxBuf.UartRx[Temp]; 
            if ( (dat >= '0') &&  (dat <= '9'))
            {
                dat = dat - '0';
            }
            else if ( (dat >= 'A')&&(dat<='F') )
            {
                dat = dat - 'A' + 10;              
            }
            
            else if ( (dat >= 'a')&&(dat<='f') )
            {
                dat = dat - 'a' + 10;              
            }
             
            else 
            {
                stcSysRun.UartRxFlag = TRUE;
                stcSysRun.UartRxValid = FALSE;
                stcSysRun.UartRxData = '\0';
                stcUartRxBuf.RxCnt = 0x0;
                stcUartRxBuf.RxFlg = FALSE;              
                return;
            }
            ChgValue = (ChgValue<<4) + dat; 
        }
        stcSysRun.UartRxData = ChgValue;
        stcSysRun.UartRxFlag = TRUE;
        stcSysRun.UartRxValid = TRUE;
        stcUartRxBuf.RxCnt = 0x0;
        stcUartRxBuf.RxFlg = FALSE; 
        return;
    }
    
    else                                                    //input decimal
    {
        ChgValue = 0;
        for ( Temp=0; Temp<RxCnt; Temp++)
        {
            dat = stcUartRxBuf.UartRx[Temp];  
            if ( (dat >= '0') &&  (dat <= '9'))
             {
                 dat = dat - '0';
             }
            else 
            {
                stcSysRun.UartRxFlag = TRUE;
                stcSysRun.UartRxValid = FALSE;
                stcSysRun.UartRxData = '\0';
                stcUartRxBuf.RxCnt = 0x0;
                stcUartRxBuf.RxFlg = FALSE;              
                return;
            }
            ChgValue = ChgValue*10 + dat;  
        }        
        stcSysRun.UartRxData = ChgValue;
        stcSysRun.UartRxFlag = TRUE;
        stcSysRun.UartRxValid = TRUE;
        stcUartRxBuf.RxCnt = 0x0;
        stcUartRxBuf.RxFlg = FALSE; 
        return;                
    }     
}

/******************************************************************************/
/* EOF (not truncated)                                                        */
/******************************************************************************/
