
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'adc_01_sa_base' 
 * Target:  'adc_01_sa_base_Release' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "hc32f460p.h"


#endif /* RTE_COMPONENTS_H */
